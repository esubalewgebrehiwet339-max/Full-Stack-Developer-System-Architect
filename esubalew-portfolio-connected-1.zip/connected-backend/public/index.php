<?php
/**
 * public/index.php
 * ============================================================
 * Front Controller — every HTTP request enters here.
 *
 * Responsibilities:
 *   1. Bootstrap autoloader + environment
 *   2. Set security & CORS headers
 *   3. Apply global rate limiting
 *   4. Route the request to the correct controller
 *   5. Handle 404 / method-not-allowed
 * ============================================================
 */

declare(strict_types=1);

define('ROOT_PATH', dirname(__DIR__));
define('APP_START', microtime(true));

// ── 1. Autoloader ─────────────────────────────────────────────
require ROOT_PATH . '/vendor/autoload.php';

// ── 2. Environment variables ──────────────────────────────────
$dotenv = Dotenv\Dotenv::createImmutable(ROOT_PATH);
$dotenv->safeLoad();

// ── 3. Bootstrap app ──────────────────────────────────────────
use App\Utils\Response;
use App\Utils\RateLimiter;
use App\Middleware\CorsMiddleware;
use App\Middleware\SecurityHeadersMiddleware;
use App\Routes\Router;

// Initialise logger first so all subsequent code can log
$logger = \App\Utils\Logger::getInstance();

try {
    // Apply security headers (Helmet equivalent)
    SecurityHeadersMiddleware::apply();

    // CORS headers
    CorsMiddleware::apply();

    // Handle preflight OPTIONS request
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    // ── 4. Global rate limiter ─────────────────────────────────
    $ip    = RateLimiter::getClientIp();
    $max   = (int)($_ENV['RATE_LIMIT_MAX']    ?? 100);
    $window = (int)($_ENV['RATE_LIMIT_WINDOW'] ?? 900);

    if (!RateLimiter::check("global:{$ip}", $max, $window)) {
        Response::error('Too many requests. Please slow down.', 429);
        exit;
    }

    // ── 5. Route the request ───────────────────────────────────
    $router = new Router();
    $router->dispatch();

} catch (\Throwable $e) {
    $logger->error('Unhandled exception: ' . $e->getMessage(), [
        'file'  => $e->getFile(),
        'line'  => $e->getLine(),
        'trace' => $_ENV['APP_ENV'] === 'development' ? $e->getTraceAsString() : null,
    ]);

    $body = ['success' => false, 'message' => 'Internal Server Error'];
    if (($_ENV['APP_ENV'] ?? 'production') === 'development') {
        $body['error'] = $e->getMessage();
        $body['file']  = $e->getFile() . ':' . $e->getLine();
    }

    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode($body);
}
