<?php
/**
 * app/Services/EmailService.php
 * ============================================================
 * Email service powered by PHPMailer + SMTP.
 *
 * Public methods:
 *   sendContactNotification(array $data)  — admin alert for new contact
 *   sendContactAutoReply(array $data)     — auto-reply to visitor
 *   sendAdminAlert(string $subject, string $html) — generic admin alert
 * ============================================================
 */

declare(strict_types=1);

namespace App\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as MailException;
use App\Utils\Logger;

class EmailService
{
    // ── Mailer factory ────────────────────────────────────────

    private static function buildMailer(): PHPMailer
    {
        $mail = new PHPMailer(true); // true = throw exceptions

        $mail->isSMTP();
        $mail->Host        = $_ENV['MAIL_HOST']     ?? 'smtp.gmail.com';
        $mail->SMTPAuth    = true;
        $mail->Username    = $_ENV['MAIL_USERNAME']  ?? '';
        $mail->Password    = $_ENV['MAIL_PASSWORD']  ?? '';
        $mail->SMTPSecure  = ($_ENV['MAIL_ENCRYPTION'] ?? 'tls') === 'ssl'
                             ? PHPMailer::ENCRYPTION_SMTPS
                             : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port        = (int)($_ENV['MAIL_PORT'] ?? 587);
        $mail->CharSet     = 'UTF-8';
        $mail->Timeout     = 10;

        // Disable SMTP debug output in production
        $mail->SMTPDebug   = ($_ENV['APP_ENV'] ?? 'production') === 'development'
                             ? SMTP::DEBUG_SERVER : SMTP::DEBUG_OFF;

        $mail->setFrom(
            $_ENV['MAIL_FROM_ADDRESS'] ?? $_ENV['MAIL_USERNAME'] ?? '',
            $_ENV['MAIL_FROM_NAME']    ?? 'Esubalew Gebrehiwet'
        );

        return $mail;
    }

    // ── Email templates ───────────────────────────────────────

    private static function layout(string $content): string
    {
        $year = date('Y');
        return <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8"/>
          <meta name="viewport" content="width=device-width,initial-scale=1"/>
          <style>
            *{margin:0;padding:0;box-sizing:border-box}
            body{background:#f1f5f9;font-family:'Segoe UI',Arial,sans-serif;padding:32px 16px}
            .card{background:#fff;border-radius:12px;max-width:560px;margin:0 auto;
                  overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08)}
            .header{background:linear-gradient(135deg,#0d1525,#111c30);padding:28px 32px}
            .header h1{color:#38bdf8;font-size:1.1rem;font-weight:700;letter-spacing:-.5px}
            .header p{color:#64748b;font-size:.78rem;margin-top:4px}
            .body{padding:28px 32px}
            .body p{color:#475569;font-size:.88rem;line-height:1.7;margin-bottom:12px}
            .field{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
                   padding:12px 16px;margin-bottom:12px}
            .field label{display:block;font-size:.7rem;font-weight:700;
                         text-transform:uppercase;letter-spacing:.08em;
                         color:#94a3b8;margin-bottom:4px}
            .field span{color:#1e293b;font-size:.88rem}
            .btn{display:inline-block;background:linear-gradient(135deg,#38bdf8,#818cf8);
                 color:#000;font-weight:700;font-size:.85rem;padding:12px 28px;
                 border-radius:8px;text-decoration:none;margin-top:8px}
            .footer{background:#f8fafc;border-top:1px solid #e2e8f0;
                    padding:16px 32px;text-align:center}
            .footer p{color:#94a3b8;font-size:.74rem;line-height:1.6}
          </style>
        </head>
        <body>
          <div class="card">
            <div class="header">
              <h1>Esubalew Gebrehiwet</h1>
              <p>Full-Stack Developer &amp; System Architect</p>
            </div>
            {$content}
            <div class="footer">
              <p>&copy; {$year} Esubalew Gebrehiwet &middot; esubalew.dev@gmail.com</p>
            </div>
          </div>
        </body>
        </html>
        HTML;
    }

    // ── Public API ────────────────────────────────────────────

    /**
     * Notify the admin that a new contact message has arrived.
     *
     * @param array{name:string,email:string,projectType?:string,budget?:string,message:string} $data
     */
    public static function sendContactNotification(array $data): void
    {
        $name        = htmlspecialchars($data['name'],        ENT_QUOTES);
        $email       = htmlspecialchars($data['email'],       ENT_QUOTES);
        $projectType = htmlspecialchars($data['projectType'] ?? 'Not specified', ENT_QUOTES);
        $budget      = htmlspecialchars($data['budget']      ?? 'Not specified', ENT_QUOTES);
        $message     = nl2br(htmlspecialchars($data['message'], ENT_QUOTES));

        $body = self::layout(<<<HTML
        <div class="body">
          <p>You have received a new contact form submission.</p>
          <div class="field"><label>Name</label><span>{$name}</span></div>
          <div class="field"><label>Email</label><span>{$email}</span></div>
          <div class="field"><label>Project Type</label><span>{$projectType}</span></div>
          <div class="field"><label>Budget</label><span>{$budget}</span></div>
          <div class="field"><label>Message</label><span>{$message}</span></div>
          <a href="mailto:{$email}" class="btn">Reply to {$name} &rarr;</a>
        </div>
        HTML);

        self::send(
            to:      $_ENV['ADMIN_EMAIL'] ?? $_ENV['MAIL_USERNAME'] ?? '',
            subject: "📩 New Contact: {$name} — {$projectType}",
            html:    $body,
            replyTo: $data['email']
        );
    }

    /**
     * Send an auto-reply to the visitor who submitted the form.
     *
     * @param array{name:string,email:string} $data
     */
    public static function sendContactAutoReply(array $data): void
    {
        $name = htmlspecialchars($data['name'], ENT_QUOTES);

        $body = self::layout(<<<HTML
        <div class="body">
          <p>Hi <strong>{$name}</strong>,</p>
          <p>
            Thank you for reaching out! I've received your message and will get back
            to you within <strong>24 hours</strong>.
          </p>
          <p>
            In the meantime, feel free to explore my portfolio or connect with me on
            LinkedIn and GitHub.
          </p>
          <p style="margin-top:16px;">
            Best regards,<br/>
            <strong>Esubalew Gebrehiwet</strong>
          </p>
        </div>
        HTML);

        self::send(
            to:      $data['email'],
            subject: "✅ Got your message, {$name}! I'll be in touch soon.",
            html:    $body
        );
    }

    /**
     * Send a generic admin alert email.
     */
    public static function sendAdminAlert(string $subject, string $htmlContent): void
    {
        $body = self::layout("<div class=\"body\">{$htmlContent}</div>");

        self::send(
            to:      $_ENV['ADMIN_EMAIL'] ?? $_ENV['MAIL_USERNAME'] ?? '',
            subject: "[Portfolio Alert] {$subject}",
            html:    $body
        );
    }

    // ── Internal send ─────────────────────────────────────────

    private static function send(
        string  $to,
        string  $subject,
        string  $html,
        ?string $replyTo = null
    ): void {
        try {
            $mail = self::buildMailer();
            $mail->addAddress($to);

            if ($replyTo) {
                $mail->addReplyTo($replyTo);
            }

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $html;
            $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>'], "\n", $html));

            $mail->send();
            Logger::getInstance()->info("Email sent to: {$to} | Subject: {$subject}");

        } catch (MailException $e) {
            Logger::getInstance()->error("Email failed to {$to}: " . $e->getMessage());
            throw $e; // re-throw so callers can decide how to handle
        }
    }
}
