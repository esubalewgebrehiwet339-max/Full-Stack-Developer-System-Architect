<?php
/**
 * app/Routes/Router.php
 * ============================================================
 * Lightweight front-controller router.
 * Parses the request URI, matches it against registered routes,
 * runs middleware stack, then dispatches to the controller.
 * ============================================================
 */

declare(strict_types=1);

namespace App\Routes;

use App\Utils\Response;
use App\Utils\Logger;

class Router
{
    /** @var array<array{method:string, pattern:string, handler:callable, middleware:callable[]}> */
    private array $routes = [];

    public function __construct()
    {
        $this->registerRoutes();
    }

    // ── Route registration helpers ────────────────────────────

    private function get(string $pattern, callable $handler, array $mw = []): void
    {
        $this->add('GET', $pattern, $handler, $mw);
    }

    private function post(string $pattern, callable $handler, array $mw = []): void
    {
        $this->add('POST', $pattern, $handler, $mw);
    }

    private function put(string $pattern, callable $handler, array $mw = []): void
    {
        $this->add('PUT', $pattern, $handler, $mw);
    }

    private function patch(string $pattern, callable $handler, array $mw = []): void
    {
        $this->add('PATCH', $pattern, $handler, $mw);
    }

    private function delete(string $pattern, callable $handler, array $mw = []): void
    {
        $this->add('DELETE', $pattern, $handler, $mw);
    }

    private function add(string $method, string $pattern, callable $handler, array $mw): void
    {
        $this->routes[] = compact('method', 'pattern', 'handler', 'mw');
    }

    // ── Register all application routes ──────────────────────

    private function registerRoutes(): void
    {
        $auth      = new \App\Controllers\AuthController();
        $project   = new \App\Controllers\ProjectController();
        $contact   = new \App\Controllers\ContactController();
        $dashboard = new \App\Controllers\DashboardController();

        $protect   = [\App\Middleware\AuthMiddleware::class, 'handle'];
        $adminOnly = [\App\Middleware\AuthMiddleware::class, 'adminOnly'];

        // ── Health check ──────────────────────────────────────
        $this->get('/api/health', fn() => Response::json([
            'success' => true,
            'message' => 'Portfolio API is running',
            'version' => '2.0.0',
            'env'     => $_ENV['APP_ENV'] ?? 'production',
            'uptime'  => 'N/A (PHP-FPM)',
        ]));

        // ── Auth ──────────────────────────────────────────────
        $this->post('/api/auth/login', [$auth, 'login']);
        $this->get ('/api/auth/me',    [$auth, 'me'],    [$protect]);

        // ── Projects (public) ─────────────────────────────────
        $this->get('/api/projects',          [$project, 'index']);
        $this->get('/api/projects/featured', [$project, 'featured']);
        $this->get('/api/projects/{slug}',   [$project, 'show']);

        // ── Projects (admin) ──────────────────────────────────
        $this->get   ('/api/projects/admin/all',     [$project, 'adminAll'],      [$protect, $adminOnly]);
        $this->post  ('/api/projects',               [$project, 'store'],         [$protect, $adminOnly]);
        $this->put   ('/api/projects/{id}',          [$project, 'update'],        [$protect, $adminOnly]);
        $this->delete('/api/projects/{id}',          [$project, 'destroy'],       [$protect, $adminOnly]);
        $this->patch ('/api/projects/{id}/toggle',   [$project, 'togglePublish'], [$protect, $adminOnly]);

        // ── Contact (public) ──────────────────────────────────
        $this->post('/api/contact', [$contact, 'store']);

        // ── Contact (admin) ───────────────────────────────────
        $this->get   ('/api/contact',             [$contact, 'index'],        [$protect, $adminOnly]);
        $this->get   ('/api/contact/{id}',        [$contact, 'show'],         [$protect, $adminOnly]);
        $this->patch ('/api/contact/{id}/status', [$contact, 'updateStatus'], [$protect, $adminOnly]);
        $this->delete('/api/contact/{id}',        [$contact, 'destroy'],      [$protect, $adminOnly]);

        // ── Dashboard (admin) ─────────────────────────────────
        $this->get('/api/dashboard/stats', [$dashboard, 'stats'], [$protect, $adminOnly]);
    }

    // ── Request dispatcher ────────────────────────────────────

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';
        $uri    = rtrim($uri, '/') ?: '/';

        foreach ($this->routes as $route) {
            if ($route['method'] !== $method) continue;

            $params = $this->matchPattern($route['pattern'], $uri);
            if ($params === null) continue;

            // Run middleware chain
            foreach ($route['mw'] as $mw) {
                $mw($params);   // middleware calls Response::error() + exit on failure
            }

            // Parse JSON body once and store globally
            $this->parseJsonBody();

            // Dispatch to controller
            call_user_func($route['handler'], $params);
            return;
        }

        // 404 — No route matched
        Response::error("Route {$method} {$uri} not found", 404);
    }

    /**
     * Match a URI against a route pattern.
     * Returns array of captured named params or null if no match.
     *
     * Converts {param} placeholders to named regex groups.
     */
    private function matchPattern(string $pattern, string $uri): ?array
    {
        // Escape slashes and replace {param} with named capture groups
        $regex = preg_replace('/\{([a-zA-Z_]+)\}/', '(?P<$1>[^/]+)', $pattern);
        $regex = '#^' . $regex . '$#';

        if (!preg_match($regex, $uri, $matches)) {
            return null;
        }

        // Return only named captures (string keys)
        return array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
    }

    /** Parse JSON body into $_POST-equivalent globals. */
    private function parseJsonBody(): void
    {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
        if (str_contains($contentType, 'application/json')) {
            $raw  = file_get_contents('php://input');
            $data = json_decode($raw, true);
            if (is_array($data)) {
                foreach ($data as $k => $v) {
                    $_POST[$k] = $v;
                }
            }
        }
    }
}
