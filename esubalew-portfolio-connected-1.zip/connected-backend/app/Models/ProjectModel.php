<?php
/**
 * app/Models/ProjectModel.php
 * ============================================================
 * Data-access layer for the `projects` table.
 * `tech` column is stored as JSON and decoded on read.
 * ============================================================
 */

declare(strict_types=1);

namespace App\Models;

use App\Config\Database;

class ProjectModel
{
    // ── Read operations ───────────────────────────────────────

    /**
     * List published projects with optional filters and pagination.
     *
     * @param array{category?:string, featured?:bool} $filters
     * @param int $page
     * @param int $limit
     * @param string $sort  column name, prefix with - for DESC
     * @return array{rows:array[], total:int}
     */
    public static function paginate(
        array $filters = [],
        int   $page    = 1,
        int   $limit   = 10,
        string $sort   = 'sort_order'
    ): array {
        $where  = ['is_published = 1'];
        $params = [];

        if (!empty($filters['category'])) {
            $where[]  = 'category = ?';
            $params[] = $filters['category'];
        }

        if (isset($filters['featured']) && $filters['featured']) {
            $where[]  = 'featured = 1';
        }

        $whereSQL = implode(' AND ', $where);

        // Safe sort — whitelist columns
        $allowed   = ['sort_order', 'title', 'created_at'];
        $direction = 'ASC';
        if (str_starts_with($sort, '-')) {
            $sort      = ltrim($sort, '-');
            $direction = 'DESC';
        }
        $sortCol = in_array($sort, $allowed, true) ? $sort : 'sort_order';

        $offset = ($page - 1) * $limit;

        $rows = Database::query(
            "SELECT * FROM projects WHERE {$whereSQL}
              ORDER BY {$sortCol} {$direction}
              LIMIT ? OFFSET ?",
            [...$params, $limit, $offset]
        );

        $countRow = Database::queryOne(
            "SELECT COUNT(*) AS total FROM projects WHERE {$whereSQL}",
            $params
        );

        return [
            'rows'  => array_map([self::class, 'decode'], $rows),
            'total' => (int)($countRow['total'] ?? 0),
        ];
    }

    /** Get all projects including unpublished (admin). */
    public static function all(): array
    {
        $rows = Database::query('SELECT * FROM projects ORDER BY sort_order ASC');
        return array_map([self::class, 'decode'], $rows);
    }

    /** Get featured published projects (max 6). */
    public static function featured(int $limit = 6): array
    {
        $rows = Database::query(
            'SELECT * FROM projects WHERE is_published = 1 AND featured = 1
              ORDER BY sort_order ASC LIMIT ?',
            [$limit]
        );
        return array_map([self::class, 'decode'], $rows);
    }

    /** Find a single published project by slug. */
    public static function findBySlug(string $slug): ?array
    {
        $row = Database::queryOne(
            'SELECT * FROM projects WHERE slug = ? AND is_published = 1 LIMIT 1',
            [$slug]
        );
        return $row ? self::decode($row) : null;
    }

    /** Find any project by ID (admin use). */
    public static function findById(int $id): ?array
    {
        $row = Database::queryOne(
            'SELECT * FROM projects WHERE id = ? LIMIT 1',
            [$id]
        );
        return $row ? self::decode($row) : null;
    }

    // ── Write operations ──────────────────────────────────────

    /** Insert a new project. Returns new ID. */
    public static function create(array $data): int
    {
        $slug = $data['slug'] ?? self::makeSlug($data['title']);

        Database::execute(
            'INSERT INTO projects
               (title, slug, category, description, long_description, tech,
                image_url, live_url, github_url, featured, sort_order, is_published)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                $data['title'],
                $slug,
                $data['category'],
                $data['description'],
                $data['long_description'] ?? null,
                json_encode($data['tech'] ?? []),
                $data['image_url']   ?? null,
                $data['live_url']    ?? null,
                $data['github_url']  ?? null,
                (int)($data['featured']     ?? 0),
                (int)($data['order']        ?? 0),
                (int)($data['is_published'] ?? 1),
            ]
        );

        return (int)Database::lastInsertId();
    }

    /** Update a project by ID. Returns rows affected. */
    public static function update(int $id, array $data): int
    {
        $fields = [];
        $params = [];

        $map = [
            'title'            => 'title',
            'category'         => 'category',
            'description'      => 'description',
            'long_description' => 'long_description',
            'image_url'        => 'image_url',
            'live_url'         => 'live_url',
            'github_url'       => 'github_url',
            'featured'         => 'featured',
            'order'            => 'sort_order',
            'is_published'     => 'is_published',
        ];

        foreach ($map as $inputKey => $col) {
            if (array_key_exists($inputKey, $data)) {
                $fields[] = "{$col} = ?";
                $params[] = $data[$inputKey];
            }
        }

        // tech is JSON
        if (array_key_exists('tech', $data)) {
            $fields[] = 'tech = ?';
            $params[] = json_encode($data['tech']);
        }

        // Re-generate slug if title changed
        if (array_key_exists('title', $data)) {
            $fields[] = 'slug = ?';
            $params[] = self::makeSlug($data['title']);
        }

        if (empty($fields)) return 0;

        $params[] = $id;
        return Database::execute(
            'UPDATE projects SET ' . implode(', ', $fields) . ' WHERE id = ?',
            $params
        );
    }

    /** Delete a project by ID. */
    public static function delete(int $id): int
    {
        return Database::execute('DELETE FROM projects WHERE id = ?', [$id]);
    }

    /** Toggle published status. Returns new status (0|1). */
    public static function togglePublished(int $id): int
    {
        Database::execute(
            'UPDATE projects SET is_published = NOT is_published WHERE id = ?',
            [$id]
        );
        $row = Database::queryOne('SELECT is_published FROM projects WHERE id = ?', [$id]);
        return (int)($row['is_published'] ?? 0);
    }

    // ── Helpers ───────────────────────────────────────────────

    /** Decode JSON `tech` field on a project row. */
    private static function decode(array $row): array
    {
        if (isset($row['tech']) && is_string($row['tech'])) {
            $row['tech'] = json_decode($row['tech'], true) ?? [];
        }
        // Cast booleans
        $row['featured']    = (bool)$row['featured'];
        $row['is_published'] = (bool)$row['is_published'];
        $row['sort_order']  = (int)$row['sort_order'];
        return $row;
    }

    /** Generate a URL-safe slug from a title. */
    public static function makeSlug(string $title): string
    {
        $slug = strtolower(trim($title));
        $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
        $slug = preg_replace('/[\s-]+/', '-', $slug);
        return trim($slug, '-');
    }
}
