<?php
/**
 * app/Models/UserModel.php
 * ============================================================
 * Data-access layer for the `users` table.
 * ============================================================
 */

declare(strict_types=1);

namespace App\Models;

use App\Config\Database;

class UserModel
{
    /** Find a user by email (includes password hash for auth). */
    public static function findByEmail(string $email): ?array
    {
        return Database::queryOne(
            'SELECT id, name, email, password, role, last_login, created_at
               FROM users
              WHERE email = ?
              LIMIT 1',
            [strtolower(trim($email))]
        );
    }

    /** Find a user by ID (no password). */
    public static function findById(int $id): ?array
    {
        return Database::queryOne(
            'SELECT id, name, email, role, last_login, created_at
               FROM users
              WHERE id = ?
              LIMIT 1',
            [$id]
        );
    }

    /** Create a new admin user. Returns new user ID. */
    public static function create(string $name, string $email, string $hashedPassword): int
    {
        Database::execute(
            'INSERT INTO users (name, email, password, role)
             VALUES (?, ?, ?, ?)',
            [trim($name), strtolower(trim($email)), $hashedPassword, 'admin']
        );
        return (int)Database::lastInsertId();
    }

    /** Update last_login timestamp. */
    public static function touchLogin(int $id): void
    {
        Database::execute(
            'UPDATE users SET last_login = NOW() WHERE id = ?',
            [$id]
        );
    }

    /** Check whether an email already exists. */
    public static function emailExists(string $email): bool
    {
        $row = Database::queryOne(
            'SELECT id FROM users WHERE email = ? LIMIT 1',
            [strtolower(trim($email))]
        );
        return $row !== null;
    }
}
