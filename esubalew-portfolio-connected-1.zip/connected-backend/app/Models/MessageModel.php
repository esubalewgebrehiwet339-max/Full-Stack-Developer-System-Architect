<?php
/**
 * app/Models/MessageModel.php
 * ============================================================
 * Data-access layer for the `messages` table.
 * ============================================================
 */

declare(strict_types=1);

namespace App\Models;

use App\Config\Database;

class MessageModel
{
    // ── Read ──────────────────────────────────────────────────

    /**
     * Paginate messages with optional status filter.
     * @return array{rows:array[], total:int, summary:array}
     */
    public static function paginate(
        ?string $status = null,
        int     $page   = 1,
        int     $limit  = 20
    ): array {
        $where  = [];
        $params = [];

        $allowed = ['new', 'read', 'replied', 'archived'];
        if ($status && in_array($status, $allowed, true)) {
            $where[]  = 'status = ?';
            $params[] = $status;
        }

        $whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $offset   = ($page - 1) * $limit;

        $rows = Database::query(
            "SELECT * FROM messages {$whereSQL} ORDER BY created_at DESC LIMIT ? OFFSET ?",
            [...$params, $limit, $offset]
        );

        $total = (int)(Database::queryOne(
            "SELECT COUNT(*) AS c FROM messages {$whereSQL}",
            $params
        )['c'] ?? 0);

        // Counts by status for dashboard summary
        $summary = [];
        foreach ($allowed as $s) {
            $r = Database::queryOne("SELECT COUNT(*) AS c FROM messages WHERE status = ?", [$s]);
            $summary[$s] = (int)($r['c'] ?? 0);
        }

        return ['rows' => $rows, 'total' => $total, 'summary' => $summary];
    }

    /** Find a message by ID. */
    public static function findById(int $id): ?array
    {
        return Database::queryOne('SELECT * FROM messages WHERE id = ? LIMIT 1', [$id]);
    }

    // ── Write ─────────────────────────────────────────────────

    /** Insert a new contact message. Returns new ID. */
    public static function create(array $data): int
    {
        Database::execute(
            'INSERT INTO messages (name, email, project_type, budget, message, ip_address)
             VALUES (?, ?, ?, ?, ?, ?)',
            [
                $data['name'],
                strtolower(trim($data['email'])),
                $data['project_type'] ?? null,
                $data['budget']       ?? null,
                $data['message'],
                $data['ip_address']   ?? null,
            ]
        );
        return (int)Database::lastInsertId();
    }

    /** Mark message as 'read' (only if currently 'new'). */
    public static function markRead(int $id): void
    {
        Database::execute(
            "UPDATE messages SET status = 'read' WHERE id = ? AND status = 'new'",
            [$id]
        );
    }

    /** Update message status (and optional admin reply). */
    public static function updateStatus(int $id, string $status, ?string $adminReply = null): int
    {
        if ($status === 'replied') {
            return Database::execute(
                'UPDATE messages SET status = ?, admin_reply = ?, replied_at = NOW() WHERE id = ?',
                [$status, $adminReply, $id]
            );
        }
        return Database::execute(
            'UPDATE messages SET status = ? WHERE id = ?',
            [$status, $id]
        );
    }

    /** Delete a message by ID. */
    public static function delete(int $id): int
    {
        return Database::execute('DELETE FROM messages WHERE id = ?', [$id]);
    }

    // ── Stats ─────────────────────────────────────────────────

    public static function countByStatus(string $status): int
    {
        $row = Database::queryOne(
            'SELECT COUNT(*) AS c FROM messages WHERE status = ?', [$status]
        );
        return (int)($row['c'] ?? 0);
    }

    public static function countTotal(): int
    {
        $row = Database::queryOne('SELECT COUNT(*) AS c FROM messages');
        return (int)($row['c'] ?? 0);
    }

    /** Return the 5 most recent messages (for dashboard). */
    public static function recent(int $limit = 5): array
    {
        return Database::query(
            'SELECT id, name, email, status, created_at FROM messages ORDER BY created_at DESC LIMIT ?',
            [$limit]
        );
    }
}
