<?php
/**
 * app/Middleware/AuthMiddleware.php
 * ============================================================
 * JWT Bearer-token verification middleware.
 *
 * Usage in routes:
 *   [$protect]             — require any valid JWT
 *   [$protect, $adminOnly] — require admin role
 * ============================================================
 */

declare(strict_types=1);

namespace App\Middleware;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Firebase\JWT\ExpiredException;
use Firebase\JWT\SignatureInvalidException;
use App\Models\UserModel;
use App\Utils\Response;
use App\Utils\Logger;

class AuthMiddleware
{
    /**
     * Verify the Bearer JWT from Authorization header.
     * Attaches decoded user data to $_REQUEST['_user'].
     */
    public static function handle(array $params = []): void
    {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION']
                   ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
                   ?? '';

        if (!str_starts_with($authHeader, 'Bearer ')) {
            Response::error('Not authorised. No token provided.', 401);
            exit;
        }

        $token  = substr($authHeader, 7);
        $secret = $_ENV['JWT_SECRET'] ?? '';

        if (!$secret) {
            Logger::getInstance()->error('JWT_SECRET is not configured');
            Response::error('Server configuration error.', 500);
            exit;
        }

        try {
            $decoded = JWT::decode($token, new Key($secret, 'HS256'));
            $userId  = $decoded->sub ?? null;

            if (!$userId) {
                Response::error('Invalid token payload.', 401);
                exit;
            }

            // Verify the user still exists in the database
            $user = UserModel::findById((int)$userId);
            if (!$user) {
                Response::error('User no longer exists.', 401);
                exit;
            }

            // Attach user to request context
            $_REQUEST['_user'] = $user;

        } catch (ExpiredException $e) {
            Response::error('Token expired. Please log in again.', 401);
            exit;
        } catch (SignatureInvalidException $e) {
            Response::error('Invalid token signature.', 401);
            exit;
        } catch (\Throwable $e) {
            Logger::getInstance()->warning('JWT decode error: ' . $e->getMessage());
            Response::error('Invalid token.', 401);
            exit;
        }
    }

    /**
     * Restrict access to admin role only.
     * Must run AFTER handle().
     */
    public static function adminOnly(array $params = []): void
    {
        $user = $_REQUEST['_user'] ?? null;

        if (!$user || ($user['role'] ?? '') !== 'admin') {
            Response::error("You do not have permission to access this resource.", 403);
            exit;
        }
    }
}
