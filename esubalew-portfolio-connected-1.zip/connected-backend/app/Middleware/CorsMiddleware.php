<?php
/**
 * app/Middleware/CorsMiddleware.php
 * ============================================================
 * Sets CORS headers allowing the frontend origin to call the API.
 * ============================================================
 */

declare(strict_types=1);

namespace App\Middleware;

class CorsMiddleware
{
    public static function apply(): void
    {
        // Origins explicitly whitelisted via env
        $envOrigins = array_filter(array_map(
            'trim',
            explode(',', $_ENV['FRONTEND_URL'] ?? '')
        ));

        // Common local development origins (Live Server, Vite, etc.)
        $devOrigins = (($_ENV['APP_ENV'] ?? 'production') === 'development') ? [
            'http://localhost:3000',
            'http://localhost:5173',
            'http://localhost:5500',
            'http://localhost:8080',
            'http://127.0.0.1:3000',
            'http://127.0.0.1:5173',
            'http://127.0.0.1:5500',
            'http://127.0.0.1:8080',
        ] : [];

        $allowed = array_unique(array_merge($envOrigins, $devOrigins));

        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

        if ($origin && in_array($origin, $allowed, true)) {
            header("Access-Control-Allow-Origin: {$origin}");
            header('Access-Control-Allow-Credentials: true');
        }

        header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
        header('Access-Control-Max-Age: 86400');
    }
}
