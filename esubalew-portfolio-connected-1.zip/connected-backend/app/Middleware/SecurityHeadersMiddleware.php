<?php
/**
 * app/Middleware/SecurityHeadersMiddleware.php
 * ============================================================
 * HTTP security headers (equivalent to Helmet.js).
 * ============================================================
 */

declare(strict_types=1);

namespace App\Middleware;

class SecurityHeadersMiddleware
{
    public static function apply(): void
    {
        // Prevent MIME-type sniffing
        header('X-Content-Type-Options: nosniff');

        // Deny framing (clickjacking)
        header('X-Frame-Options: DENY');

        // XSS filter for older browsers
        header('X-XSS-Protection: 1; mode=block');

        // Strict HTTPS (1 year) — enable in production only
        if (($_ENV['APP_ENV'] ?? 'development') === 'production') {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }

        // Referrer policy
        header('Referrer-Policy: strict-origin-when-cross-origin');

        // Content-Security-Policy for the API (API-only, no HTML)
        header("Content-Security-Policy: default-src 'none'");

        // Hide server identity
        header_remove('X-Powered-By');
        header_remove('Server');

        // Force JSON content type for all API responses
        header('Content-Type: application/json; charset=UTF-8');
    }
}
