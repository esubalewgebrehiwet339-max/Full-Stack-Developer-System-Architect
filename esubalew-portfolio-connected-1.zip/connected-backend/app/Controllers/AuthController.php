<?php
/**
 * app/Controllers/AuthController.php
 * ============================================================
 * POST /api/auth/login  — authenticate and return JWT
 * GET  /api/auth/me     — return current admin user
 * ============================================================
 */

declare(strict_types=1);

namespace App\Controllers;

use Firebase\JWT\JWT;
use App\Models\UserModel;
use App\Utils\Response;
use App\Utils\Validator;
use App\Utils\Logger;

class AuthController
{
    /**
     * POST /api/auth/login
     * Body: { email, password }
     */
    public function login(array $params = []): void
    {
        // ── Validate input ────────────────────────────────────
        $rules = [
            'email'    => 'required|email',
            'password' => 'required|min:6',
        ];

        $v = new Validator($_POST, $rules);
        if (!$v->passes()) {
            Response::validationError($v->errors());
            return;
        }

        $email    = strtolower(trim($_POST['email']));
        $password = $_POST['password'];

        // ── Find user ─────────────────────────────────────────
        $user = UserModel::findByEmail($email);

        // Constant-time comparison — same message for wrong email or wrong password
        if (!$user || !password_verify($password, $user['password'])) {
            Response::error('Invalid email or password.', 401);
            return;
        }

        // ── Sign JWT ──────────────────────────────────────────
        $expiresHours = (int)($_ENV['JWT_EXPIRES_HOURS'] ?? 168); // 7 days
        $now          = time();

        $payload = [
            'sub'  => $user['id'],
            'name' => $user['name'],
            'role' => $user['role'],
            'iat'  => $now,
            'exp'  => $now + ($expiresHours * 3600),
        ];

        $token = JWT::encode($payload, $_ENV['JWT_SECRET'], 'HS256');

        // Update last_login
        UserModel::touchLogin((int)$user['id']);

        Logger::getInstance()->info("Admin logged in: {$user['email']}");

        // ── Respond ───────────────────────────────────────────
        Response::success([
            'token'     => $token,
            'expiresIn' => "{$expiresHours}h",
            'user'      => [
                'id'    => $user['id'],
                'name'  => $user['name'],
                'email' => $user['email'],
                'role'  => $user['role'],
            ],
        ], 'Login successful');
    }

    /**
     * GET /api/auth/me
     * Requires: Bearer JWT (set by AuthMiddleware)
     */
    public function me(array $params = []): void
    {
        $user = $_REQUEST['_user'] ?? null;

        if (!$user) {
            Response::error('Not authenticated.', 401);
            return;
        }

        Response::success($user);
    }
}
