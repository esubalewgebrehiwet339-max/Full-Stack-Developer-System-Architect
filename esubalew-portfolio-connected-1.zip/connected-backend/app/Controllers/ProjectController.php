<?php
/**
 * app/Controllers/ProjectController.php
 * ============================================================
 * Public:
 *   GET /api/projects              — paginated list
 *   GET /api/projects/featured     — featured only
 *   GET /api/projects/{slug}       — single project
 *
 * Admin (JWT required):
 *   GET    /api/projects/admin/all        — all (incl. unpublished)
 *   POST   /api/projects                  — create
 *   PUT    /api/projects/{id}             — update
 *   DELETE /api/projects/{id}             — delete
 *   PATCH  /api/projects/{id}/toggle      — toggle published
 * ============================================================
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Models\ProjectModel;
use App\Utils\Response;
use App\Utils\Validator;
use App\Utils\Logger;

class ProjectController
{
    // ── Public ────────────────────────────────────────────────

    /** GET /api/projects */
    public function index(array $params = []): void
    {
        $page     = max(1, (int)($_GET['page']     ?? 1));
        $limit    = min(50, max(1, (int)($_GET['limit'] ?? 10)));
        $sort     = $_GET['sort']     ?? 'sort_order';
        $category = $_GET['category'] ?? null;
        $featured = isset($_GET['featured']) && $_GET['featured'] === 'true';

        $filters = [];
        if ($category) $filters['category'] = $category;
        if ($featured) $filters['featured'] = true;

        $result = ProjectModel::paginate($filters, $page, $limit, $sort);

        Response::success($result['rows'], 'Projects fetched', 200, [
            'page'    => $page,
            'limit'   => $limit,
            'total'   => $result['total'],
            'pages'   => (int)ceil($result['total'] / $limit),
            'hasNext' => ($page * $limit) < $result['total'],
            'hasPrev' => $page > 1,
        ]);
    }

    /** GET /api/projects/featured */
    public function featured(array $params = []): void
    {
        $projects = ProjectModel::featured(6);
        Response::success($projects);
    }

    /** GET /api/projects/{slug} */
    public function show(array $params = []): void
    {
        $slug    = $params['slug'] ?? '';
        $project = ProjectModel::findBySlug($slug);

        if (!$project) {
            Response::error('Project not found.', 404);
            return;
        }

        Response::success($project);
    }

    // ── Admin ─────────────────────────────────────────────────

    /** GET /api/projects/admin/all */
    public function adminAll(array $params = []): void
    {
        $projects = ProjectModel::all();
        Response::success($projects, 'Projects fetched', 200, ['total' => count($projects)]);
    }

    /** POST /api/projects */
    public function store(array $params = []): void
    {
        $rules = [
            'title'       => 'required|max:120',
            'category'    => 'required|in:web,system,ecommerce,mobile,api,other',
            'description' => 'required|max:1000',
            'tech'        => 'required|array',
        ];

        $v = new Validator($_POST, $rules);
        if (!$v->passes()) {
            Response::validationError($v->errors());
            return;
        }

        try {
            $id = ProjectModel::create([
                'title'            => trim($_POST['title']),
                'category'         => $_POST['category'],
                'description'      => trim($_POST['description']),
                'long_description' => $_POST['long_description'] ?? null,
                'tech'             => $_POST['tech'],
                'image_url'        => $_POST['image_url']   ?? null,
                'live_url'         => $_POST['live_url']    ?? null,
                'github_url'       => $_POST['github_url']  ?? null,
                'featured'         => (int)($_POST['featured']     ?? 0),
                'order'            => (int)($_POST['order']        ?? 0),
                'is_published'     => (int)($_POST['is_published'] ?? 1),
            ]);

            $project = ProjectModel::findById($id);
            Logger::getInstance()->info("Project created: {$_POST['title']} ({$id})");
            Response::success($project, 'Project created successfully.', 201);

        } catch (\Throwable $e) {
            Logger::getInstance()->error('Create project error: ' . $e->getMessage());
            Response::error('Could not create project.', 500, $e->getMessage());
        }
    }

    /** PUT /api/projects/{id} */
    public function update(array $params = []): void
    {
        $id = (int)($params['id'] ?? 0);

        if (!ProjectModel::findById($id)) {
            Response::error('Project not found.', 404);
            return;
        }

        $rules = [
            'title'       => 'required|max:120',
            'category'    => 'required|in:web,system,ecommerce,mobile,api,other',
            'description' => 'required|max:1000',
            'tech'        => 'required|array',
        ];

        $v = new Validator($_POST, $rules);
        if (!$v->passes()) {
            Response::validationError($v->errors());
            return;
        }

        try {
            ProjectModel::update($id, [
                'title'            => trim($_POST['title']),
                'category'         => $_POST['category'],
                'description'      => trim($_POST['description']),
                'long_description' => $_POST['long_description'] ?? null,
                'tech'             => $_POST['tech'],
                'image_url'        => $_POST['image_url']   ?? null,
                'live_url'         => $_POST['live_url']    ?? null,
                'github_url'       => $_POST['github_url']  ?? null,
                'featured'         => (int)($_POST['featured']     ?? 0),
                'order'            => (int)($_POST['order']        ?? 0),
                'is_published'     => (int)($_POST['is_published'] ?? 1),
            ]);

            $project = ProjectModel::findById($id);
            Logger::getInstance()->info("Project updated: {$id}");
            Response::success($project, 'Project updated successfully.');

        } catch (\Throwable $e) {
            Logger::getInstance()->error('Update project error: ' . $e->getMessage());
            Response::error('Could not update project.', 500, $e->getMessage());
        }
    }

    /** DELETE /api/projects/{id} */
    public function destroy(array $params = []): void
    {
        $id = (int)($params['id'] ?? 0);

        if (!ProjectModel::findById($id)) {
            Response::error('Project not found.', 404);
            return;
        }

        ProjectModel::delete($id);
        Logger::getInstance()->info("Project deleted: {$id}");
        Response::success(null, 'Project deleted successfully.');
    }

    /** PATCH /api/projects/{id}/toggle */
    public function togglePublish(array $params = []): void
    {
        $id = (int)($params['id'] ?? 0);

        if (!ProjectModel::findById($id)) {
            Response::error('Project not found.', 404);
            return;
        }

        $newStatus = ProjectModel::togglePublished($id);
        $project   = ProjectModel::findById($id);
        $label     = $newStatus ? 'published' : 'unpublished';

        Response::success($project, "Project {$label}.");
    }
}
