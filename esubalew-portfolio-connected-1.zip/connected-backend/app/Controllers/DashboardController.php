<?php
/**
 * app/Controllers/DashboardController.php
 * ============================================================
 * GET /api/dashboard/stats — admin aggregate statistics
 * ============================================================
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Config\Database;
use App\Models\ProjectModel;
use App\Models\MessageModel;
use App\Utils\Response;
use App\Utils\Logger;

class DashboardController
{
    /** GET /api/dashboard/stats */
    public function stats(array $params = []): void
    {
        try {
            // ── Project counts ────────────────────────────────
            $totalProjects     = (int)(Database::queryOne('SELECT COUNT(*) AS c FROM projects')['c']               ?? 0);
            $publishedProjects = (int)(Database::queryOne('SELECT COUNT(*) AS c FROM projects WHERE is_published = 1')['c'] ?? 0);
            $featuredProjects  = (int)(Database::queryOne('SELECT COUNT(*) AS c FROM projects WHERE featured = 1')['c']    ?? 0);

            // Projects grouped by category
            $byCategory = [];
            $catRows    = Database::query('SELECT category, COUNT(*) AS c FROM projects GROUP BY category');
            foreach ($catRows as $row) {
                $byCategory[$row['category']] = (int)$row['c'];
            }

            // ── Message counts ────────────────────────────────
            $totalMessages   = MessageModel::countTotal();
            $newMessages     = MessageModel::countByStatus('new');
            $repliedMessages = MessageModel::countByStatus('replied');
            $recentMessages  = MessageModel::recent(5);

            // Messages grouped by status
            $byStatus = [];
            $statuses = ['new', 'read', 'replied', 'archived'];
            foreach ($statuses as $s) {
                $byStatus[$s] = MessageModel::countByStatus($s);
            }

            // ── PHP runtime info ──────────────────────────────
            $memoryMb = round(memory_get_usage(true) / 1024 / 1024, 2);

            Response::success([
                'projects' => [
                    'total'      => $totalProjects,
                    'published'  => $publishedProjects,
                    'featured'   => $featuredProjects,
                    'byCategory' => $byCategory,
                ],
                'messages' => [
                    'total'    => $totalMessages,
                    'new'      => $newMessages,
                    'replied'  => $repliedMessages,
                    'pending'  => $totalMessages - $repliedMessages,
                    'byStatus' => $byStatus,
                    'recent'   => $recentMessages,
                ],
                'server' => [
                    'environment' => $_ENV['APP_ENV'] ?? 'production',
                    'php_version' => PHP_VERSION,
                    'memory_mb'   => $memoryMb,
                    'timestamp'   => date('c'),
                ],
            ]);

        } catch (\Throwable $e) {
            Logger::getInstance()->error('Dashboard stats error: ' . $e->getMessage());
            Response::error('Could not fetch dashboard stats.', 500, $e->getMessage());
        }
    }
}
