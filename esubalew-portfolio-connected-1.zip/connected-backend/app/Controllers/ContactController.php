<?php
/**
 * app/Controllers/ContactController.php
 * ============================================================
 * Public:
 *   POST /api/contact              — submit contact form
 *
 * Admin:
 *   GET    /api/contact            — list messages
 *   GET    /api/contact/{id}       — get single message
 *   PATCH  /api/contact/{id}/status
 *   DELETE /api/contact/{id}
 * ============================================================
 */

declare(strict_types=1);

namespace App\Controllers;

use App\Models\MessageModel;
use App\Services\EmailService;
use App\Utils\Response;
use App\Utils\Validator;
use App\Utils\RateLimiter;
use App\Utils\Logger;

class ContactController
{
    // ── Public ────────────────────────────────────────────────

    /** POST /api/contact */
    public function store(array $params = []): void
    {
        // Stricter per-IP rate limit for contact form (5 per 15 min)
        $ip     = RateLimiter::getClientIp();
        $maxMsg = (int)($_ENV['CONTACT_RATE_LIMIT_MAX'] ?? 5);

        if (!RateLimiter::check("contact:{$ip}", $maxMsg, 900)) {
            Response::error('Too many messages from this IP. Please wait 15 minutes.', 429);
            return;
        }

        // Validate
        $rules = [
            'name'    => 'required|max:80',
            'email'   => 'required|email',
            'message' => 'required|min:20|max:3000',
        ];

        $v = new Validator($_POST, $rules);
        if (!$v->passes()) {
            Response::validationError($v->errors());
            return;
        }

        $name        = htmlspecialchars(trim($_POST['name']),    ENT_QUOTES);
        $email       = strtolower(trim($_POST['email']));
        $projectType = $_POST['project_type'] ?? null;
        $budget      = $_POST['budget']       ?? null;
        $message     = htmlspecialchars(trim($_POST['message']), ENT_QUOTES);

        try {
            // Persist to DB
            $id = MessageModel::create([
                'name'         => $name,
                'email'        => $email,
                'project_type' => $projectType,
                'budget'       => $budget,
                'message'      => $message,
                'ip_address'   => $ip,
            ]);

            // Fire emails (non-blocking — ignore failures)
            try {
                EmailService::sendContactNotification(compact('name', 'email', 'projectType', 'budget', 'message'));
                EmailService::sendContactAutoReply(compact('name', 'email'));
            } catch (\Throwable $emailErr) {
                Logger::getInstance()->warning('Email send failed: ' . $emailErr->getMessage());
            }

            Logger::getInstance()->info("New contact from {$name} <{$email}>");
            Response::success(['id' => $id], "Message received! I'll get back to you within 24 hours.", 201);

        } catch (\Throwable $e) {
            Logger::getInstance()->error('Contact store error: ' . $e->getMessage());
            Response::error('Could not send your message. Please try again.', 500, $e->getMessage());
        }
    }

    // ── Admin ─────────────────────────────────────────────────

    /** GET /api/contact */
    public function index(array $params = []): void
    {
        $status = $_GET['status'] ?? null;
        $page   = max(1, (int)($_GET['page']  ?? 1));
        $limit  = min(100, max(1, (int)($_GET['limit'] ?? 20)));

        $result = MessageModel::paginate($status, $page, $limit);

        Response::success($result['rows'], 'Messages fetched', 200, [
            'page'    => $page,
            'limit'   => $limit,
            'total'   => $result['total'],
            'pages'   => (int)ceil($result['total'] / max($limit, 1)),
            'summary' => $result['summary'],
        ]);
    }

    /** GET /api/contact/{id} */
    public function show(array $params = []): void
    {
        $id  = (int)($params['id'] ?? 0);
        $msg = MessageModel::findById($id);

        if (!$msg) {
            Response::error('Message not found.', 404);
            return;
        }

        // Auto-mark as read
        MessageModel::markRead($id);
        $msg['status'] = $msg['status'] === 'new' ? 'read' : $msg['status'];

        Response::success($msg);
    }

    /** PATCH /api/contact/{id}/status */
    public function updateStatus(array $params = []): void
    {
        $id     = (int)($params['id'] ?? 0);
        $status = $_POST['status'] ?? '';

        $allowed = ['new', 'read', 'replied', 'archived'];
        if (!in_array($status, $allowed, true)) {
            Response::error('Status must be one of: ' . implode(', ', $allowed), 400);
            return;
        }

        if (!MessageModel::findById($id)) {
            Response::error('Message not found.', 404);
            return;
        }

        $adminReply = $_POST['admin_reply'] ?? null;
        MessageModel::updateStatus($id, $status, $adminReply);

        $msg = MessageModel::findById($id);
        Response::success($msg, 'Status updated.');
    }

    /** DELETE /api/contact/{id} */
    public function destroy(array $params = []): void
    {
        $id = (int)($params['id'] ?? 0);

        if (!MessageModel::findById($id)) {
            Response::error('Message not found.', 404);
            return;
        }

        MessageModel::delete($id);
        Logger::getInstance()->info("Message {$id} deleted");
        Response::success(null, 'Message deleted.');
    }
}
