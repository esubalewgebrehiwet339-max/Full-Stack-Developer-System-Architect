<?php
/**
 * app/Utils/RateLimiter.php
 * ============================================================
 * Simple sliding-window rate limiter backed by the `rate_limits`
 * MySQL table (no Redis required).
 *
 * Usage:
 *   if (!RateLimiter::check("global:{$ip}", 100, 900)) {
 *       Response::error('Too many requests', 429);
 *       exit;
 *   }
 * ============================================================
 */

declare(strict_types=1);

namespace App\Utils;

use App\Config\Database;

class RateLimiter
{
    /**
     * Check whether a key is within its allowed limit.
     * Creates or increments a record in `rate_limits`.
     *
     * @param string $key     Unique identifier, e.g. "global:1.2.3.4"
     * @param int    $max     Maximum allowed attempts within the window
     * @param int    $window  Window length in seconds
     * @return bool  true = allowed, false = rate-limit exceeded
     */
    public static function check(string $key, int $max, int $window): bool
    {
        try {
            $now = date('Y-m-d H:i:s');

            // Fetch existing record
            $record = Database::queryOne(
                'SELECT id, attempts, window_end FROM rate_limits WHERE key_name = ? LIMIT 1',
                [$key]
            );

            if ($record === null) {
                // First request from this key — create a new window
                $windowEnd = date('Y-m-d H:i:s', time() + $window);
                Database::execute(
                    'INSERT INTO rate_limits (key_name, attempts, window_end)
                     VALUES (?, 1, ?)
                     ON DUPLICATE KEY UPDATE
                       attempts   = IF(window_end < NOW(), 1, attempts + 1),
                       window_end = IF(window_end < NOW(), VALUES(window_end), window_end)',
                    [$key, $windowEnd]
                );
                return true; // definitely first request
            }

            // If the window has expired, reset the counter
            if ($record['window_end'] < $now) {
                $windowEnd = date('Y-m-d H:i:s', time() + $window);
                Database::execute(
                    'UPDATE rate_limits SET attempts = 1, window_end = ? WHERE key_name = ?',
                    [$windowEnd, $key]
                );
                return true;
            }

            // Window is active — check attempts
            if ((int)$record['attempts'] >= $max) {
                return false; // exceeded
            }

            // Increment counter
            Database::execute(
                'UPDATE rate_limits SET attempts = attempts + 1 WHERE key_name = ?',
                [$key]
            );
            return true;

        } catch (\Throwable $e) {
            // If rate-limit table is unavailable, fail open (allow request)
            Logger::getInstance()->warning('RateLimiter error: ' . $e->getMessage());
            return true;
        }
    }

    /**
     * Purge expired rate-limit rows (run periodically via cron).
     */
    public static function cleanup(): void
    {
        Database::execute('DELETE FROM rate_limits WHERE window_end < NOW()');
    }

    /**
     * Detect the real client IP, respecting common proxy headers.
     */
    public static function getClientIp(): string
    {
        $headers = [
            'HTTP_CF_CONNECTING_IP',   // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];

        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                // X-Forwarded-For can be a comma-separated list
                $ip = trim(explode(',', $_SERVER[$header])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }
}
