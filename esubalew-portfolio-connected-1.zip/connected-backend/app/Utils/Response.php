<?php
/**
 * app/Utils/Response.php
 * ============================================================
 * Centralised JSON response factory.
 *
 * Every API response follows this envelope:
 * {
 *   "success" : bool,
 *   "message" : string,
 *   "data"    : mixed   (on success),
 *   "meta"    : object  (pagination / counts),
 *   "errors"  : array   (on validation failure),
 *   "error"   : string  (dev-only stack detail)
 * }
 * ============================================================
 */

declare(strict_types=1);

namespace App\Utils;

class Response
{
    /**
     * Send a successful JSON response and exit.
     *
     * @param mixed       $data
     * @param string      $message
     * @param int         $status   HTTP status code (default 200)
     * @param array|null  $meta     Pagination / extra meta
     */
    public static function success(
        mixed  $data    = null,
        string $message = 'Success',
        int    $status  = 200,
        ?array $meta    = null
    ): void {
        $body = ['success' => true, 'message' => $message];

        if ($data !== null) {
            $body['data'] = $data;
        }

        if ($meta !== null) {
            $body['meta'] = $meta;
        }

        self::send($body, $status);
    }

    /**
     * Send an error JSON response and exit.
     *
     * @param string      $message   Human-readable error description
     * @param int         $status    HTTP status code (default 500)
     * @param string|null $detail    Only included in development mode
     */
    public static function error(
        string  $message = 'Server error',
        int     $status  = 500,
        ?string $detail  = null
    ): void {
        $body = ['success' => false, 'message' => $message];

        if ($detail !== null && ($_ENV['APP_ENV'] ?? 'production') === 'development') {
            $body['error'] = $detail;
        }

        self::send($body, $status);
    }

    /**
     * Send a 422 Unprocessable Entity with field-level validation errors.
     *
     * @param array $errors  [ ['field' => '...', 'message' => '...'], ... ]
     */
    public static function validationError(array $errors): void
    {
        self::send([
            'success' => false,
            'message' => 'Validation failed',
            'errors'  => $errors,
        ], 422);
    }

    // ── Internal ──────────────────────────────────────────────

    private static function send(array $body, int $status): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}
