<?php
/**
 * app/Utils/Logger.php
 * ============================================================
 * Monolog-based logger singleton.
 *
 * - Development : coloured console output (StreamHandler → STDOUT)
 * - Production  : rotating daily file + stdout JSON
 * ============================================================
 */

declare(strict_types=1);

namespace App\Utils;

use Monolog\Logger as MonologLogger;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\RotatingFileHandler;
use Monolog\Formatter\LineFormatter;
use Monolog\Formatter\JsonFormatter;
use Monolog\Level;

class Logger
{
    private static ?MonologLogger $instance = null;

    public static function getInstance(): MonologLogger
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        $isDev  = ($_ENV['APP_ENV'] ?? 'production') === 'development';
        $logger = new MonologLogger('portfolio');

        if ($isDev) {
            // Pretty single-line format for development
            $format    = "[%datetime%] %level_name%: %message% %context%\n";
            $formatter = new LineFormatter($format, 'H:i:s', true, true);

            $stdout = new StreamHandler('php://stdout', Level::Debug);
            $stdout->setFormatter($formatter);
            $logger->pushHandler($stdout);
        } else {
            // JSON log to rotating file in production
            $logsDir  = ROOT_PATH . '/storage/logs';
            $rotating = new RotatingFileHandler(
                $logsDir . '/app.log',
                30,          // keep 30 days of log files
                Level::Info
            );
            $rotating->setFormatter(new JsonFormatter());
            $logger->pushHandler($rotating);

            // Also stream errors to STDOUT so hosting platforms capture them
            $errorOut = new StreamHandler('php://stderr', Level::Error);
            $errorOut->setFormatter(new JsonFormatter());
            $logger->pushHandler($errorOut);
        }

        self::$instance = $logger;
        return $logger;
    }

    // Prevent construction / cloning
    private function __construct() {}
    private function __clone()     {}
}
