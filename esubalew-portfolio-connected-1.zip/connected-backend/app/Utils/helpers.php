<?php
/**
 * app/Utils/helpers.php
 * ============================================================
 * Global helper functions auto-loaded via composer.json.
 * ============================================================
 */

declare(strict_types=1);

if (!function_exists('env')) {
    /**
     * Get an environment variable with an optional default.
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    function env(string $key, mixed $default = null): mixed
    {
        return $_ENV[$key] ?? $_SERVER[$key] ?? $default;
    }
}

if (!function_exists('sanitize')) {
    /**
     * Strip tags and HTML-encode a string for safe output.
     */
    function sanitize(string $value): string
    {
        return htmlspecialchars(strip_tags(trim($value)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

if (!function_exists('is_dev')) {
    /**
     * Return true if the application is running in development mode.
     */
    function is_dev(): bool
    {
        return (env('APP_ENV', 'production') === 'development');
    }
}

if (!function_exists('json_body')) {
    /**
     * Decode the raw JSON request body into an array.
     * Returns an empty array on failure.
     */
    function json_body(): array
    {
        $raw = file_get_contents('php://input');
        if (empty($raw)) return [];

        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }
}

if (!function_exists('slug')) {
    /**
     * Convert a string to a URL-safe slug.
     */
    function slug(string $text): string
    {
        $text = strtolower(trim($text));
        $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
        $text = preg_replace('/[\s-]+/', '-', $text);
        return trim($text, '-');
    }
}
