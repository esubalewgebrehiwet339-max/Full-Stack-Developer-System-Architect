<?php
/**
 * app/Utils/Validator.php
 * ============================================================
 * Lightweight rule-based input validator.
 *
 * Supported rules (pipe-separated):
 *   required         — field must be present and non-empty
 *   email            — must be a valid email address
 *   min:N            — string length >= N  (or numeric value >= N)
 *   max:N            — string length <= N  (or numeric value <= N)
 *   in:a,b,c         — value must be one of the listed options
 *   numeric          — must be numeric
 *   integer          — must be an integer
 *   array            — must be an array
 *   url              — must be a valid URL
 *
 * Usage:
 *   $v = new Validator($_POST, ['email' => 'required|email', 'name' => 'required|max:80']);
 *   if (!$v->passes()) { Response::validationError($v->errors()); }
 * ============================================================
 */

declare(strict_types=1);

namespace App\Utils;

class Validator
{
    private array $data;
    private array $rules;
    /** @var array<array{field:string, message:string}> */
    private array $errors = [];

    public function __construct(array $data, array $rules)
    {
        $this->data  = $data;
        $this->rules = $rules;
    }

    /** Run all validation rules. Returns true if no errors. */
    public function passes(): bool
    {
        $this->errors = [];

        foreach ($this->rules as $field => $ruleString) {
            $rules = explode('|', $ruleString);
            $value = $this->data[$field] ?? null;

            foreach ($rules as $rule) {
                $this->applyRule($field, $rule, $value);
            }
        }

        return empty($this->errors);
    }

    /** Return array of error objects (field + message). */
    public function errors(): array
    {
        return $this->errors;
    }

    // ── Rule engine ───────────────────────────────────────────

    private function applyRule(string $field, string $rule, mixed $value): void
    {
        // Parse rule name and optional parameter: "min:8" → ['min', '8']
        [$name, $param] = array_pad(explode(':', $rule, 2), 2, null);

        // Skip non-required rules if value is empty (unless it's the 'required' rule)
        if ($name !== 'required' && ($value === null || $value === '')) {
            return;
        }

        $label = ucfirst(str_replace('_', ' ', $field));

        match ($name) {
            'required' => $this->checkRequired($field, $label, $value),
            'email'    => $this->checkEmail($field, $label, $value),
            'min'      => $this->checkMin($field, $label, $value, (int)$param),
            'max'      => $this->checkMax($field, $label, $value, (int)$param),
            'in'       => $this->checkIn($field, $label, $value, $param),
            'numeric'  => $this->checkNumeric($field, $label, $value),
            'integer'  => $this->checkInteger($field, $label, $value),
            'array'    => $this->checkArray($field, $label, $value),
            'url'      => $this->checkUrl($field, $label, $value),
            default    => null,
        };
    }

    private function addError(string $field, string $message): void
    {
        $this->errors[] = ['field' => $field, 'message' => $message];
    }

    private function checkRequired(string $field, string $label, mixed $value): void
    {
        if ($value === null || $value === '' || (is_array($value) && empty($value))) {
            $this->addError($field, "{$label} is required.");
        }
    }

    private function checkEmail(string $field, string $label, mixed $value): void
    {
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, "{$label} must be a valid email address.");
        }
    }

    private function checkMin(string $field, string $label, mixed $value, int $min): void
    {
        $len = is_string($value) ? mb_strlen($value) : (is_numeric($value) ? (float)$value : 0);
        if ($len < $min) {
            $unit = is_string($value) ? 'characters' : '';
            $this->addError($field, "{$label} must be at least {$min} {$unit}.");
        }
    }

    private function checkMax(string $field, string $label, mixed $value, int $max): void
    {
        $len = is_string($value) ? mb_strlen($value) : (is_numeric($value) ? (float)$value : 0);
        if ($len > $max) {
            $unit = is_string($value) ? 'characters' : '';
            $this->addError($field, "{$label} cannot exceed {$max} {$unit}.");
        }
    }

    private function checkIn(string $field, string $label, mixed $value, ?string $param): void
    {
        $options = $param ? explode(',', $param) : [];
        if (!in_array($value, $options, true)) {
            $this->addError($field, "{$label} must be one of: " . implode(', ', $options) . '.');
        }
    }

    private function checkNumeric(string $field, string $label, mixed $value): void
    {
        if (!is_numeric($value)) {
            $this->addError($field, "{$label} must be a numeric value.");
        }
    }

    private function checkInteger(string $field, string $label, mixed $value): void
    {
        if (filter_var($value, FILTER_VALIDATE_INT) === false) {
            $this->addError($field, "{$label} must be an integer.");
        }
    }

    private function checkArray(string $field, string $label, mixed $value): void
    {
        if (!is_array($value)) {
            $this->addError($field, "{$label} must be an array.");
        }
    }

    private function checkUrl(string $field, string $label, mixed $value): void
    {
        if (!filter_var($value, FILTER_VALIDATE_URL)) {
            $this->addError($field, "{$label} must be a valid URL.");
        }
    }
}
