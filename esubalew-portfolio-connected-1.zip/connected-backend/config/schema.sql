-- ============================================================
-- config/schema.sql
-- Portfolio Database Schema
-- Run: mysql -u root -p portfolio < config/schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS `portfolio`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `portfolio`;

-- ── Users (admin accounts) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS `users` (
    `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(80)  NOT NULL,
    `email`       VARCHAR(180) NOT NULL UNIQUE,
    `password`    VARCHAR(255) NOT NULL,
    `role`        ENUM('admin') NOT NULL DEFAULT 'admin',
    `last_login`  DATETIME     NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Projects ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `projects` (
    `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`            VARCHAR(120)  NOT NULL,
    `slug`             VARCHAR(140)  NOT NULL UNIQUE,
    `category`         ENUM('web','system','ecommerce','mobile','api','other') NOT NULL,
    `description`      TEXT          NOT NULL,
    `long_description` LONGTEXT      NULL,
    `tech`             JSON          NOT NULL COMMENT 'Array of technology names',
    `image_url`        VARCHAR(500)  NULL,
    `live_url`         VARCHAR(500)  NULL,
    `github_url`       VARCHAR(500)  NULL,
    `featured`         TINYINT(1)   NOT NULL DEFAULT 0,
    `sort_order`       SMALLINT     NOT NULL DEFAULT 0,
    `is_published`     TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_projects_category`    (`category`),
    INDEX `idx_projects_featured`    (`featured`),
    INDEX `idx_projects_published`   (`is_published`),
    INDEX `idx_projects_order`       (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Contact Messages ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `messages` (
    `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`         VARCHAR(80)   NOT NULL,
    `email`        VARCHAR(180)  NOT NULL,
    `project_type` VARCHAR(60)   NULL,
    `budget`       VARCHAR(80)   NULL,
    `message`      TEXT          NOT NULL,
    `status`       ENUM('new','read','replied','archived') NOT NULL DEFAULT 'new',
    `admin_reply`  TEXT          NULL,
    `replied_at`   DATETIME      NULL,
    `ip_address`   VARCHAR(45)   NULL COMMENT 'IPv4 or IPv6',
    `created_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_messages_status`     (`status`),
    INDEX `idx_messages_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Rate Limit Tracking ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS `rate_limits` (
    `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key_name`   VARCHAR(200) NOT NULL UNIQUE COMMENT 'e.g. global:1.2.3.4',
    `attempts`   SMALLINT     NOT NULL DEFAULT 1,
    `window_end` DATETIME     NOT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_rate_limits_key`        (`key_name`),
    INDEX `idx_rate_limits_window_end` (`window_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
