<?php
/**
 * config/database.php
 * ============================================================
 * PDO MySQL connection singleton.
 * Returns a cached PDO instance on every call.
 * ============================================================
 */

declare(strict_types=1);

namespace App\Config;

use PDO;
use PDOException;
use App\Utils\Logger;

class Database
{
    private static ?PDO $instance = null;

    /**
     * Get the shared PDO instance (singleton).
     *
     * @throws \RuntimeException if connection fails
     */
    public static function getInstance(): PDO
    {
        if (self::$instance !== null) {
            return self::$instance;
        }

        $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
        $port = $_ENV['DB_PORT'] ?? '3306';
        $name = $_ENV['DB_NAME'] ?? 'portfolio';
        $user = $_ENV['DB_USER'] ?? 'root';
        $pass = $_ENV['DB_PASS'] ?? '';

        $dsn = "mysql:host={$host};port={$port};dbname={$name};charset=utf8mb4";

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
            // Keep connection alive
            PDO::ATTR_PERSISTENT         => false,
            // Strict mode + timezone
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci, time_zone = '+00:00'",
        ];

        try {
            self::$instance = new PDO($dsn, $user, $pass, $options);
            Logger::getInstance()->info("Database connected → {$host}/{$name}");
        } catch (PDOException $e) {
            Logger::getInstance()->error('Database connection failed: ' . $e->getMessage());
            throw new \RuntimeException('Database connection failed: ' . $e->getMessage());
        }

        return self::$instance;
    }

    /** Run a SELECT query and return all rows. */
    public static function query(string $sql, array $params = []): array
    {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Run a SELECT query and return a single row. */
    public static function queryOne(string $sql, array $params = []): ?array
    {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Run INSERT / UPDATE / DELETE and return affected rows. */
    public static function execute(string $sql, array $params = []): int
    {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    /** Return the last inserted auto-increment ID. */
    public static function lastInsertId(): string
    {
        return self::getInstance()->lastInsertId();
    }

    /** Begin a transaction. */
    public static function beginTransaction(): void
    {
        self::getInstance()->beginTransaction();
    }

    /** Commit the current transaction. */
    public static function commit(): void
    {
        self::getInstance()->commit();
    }

    /** Roll back the current transaction. */
    public static function rollback(): void
    {
        self::getInstance()->rollBack();
    }

    // Prevent construction / cloning
    private function __construct() {}
    private function __clone()     {}
}
