<?php
/**
 * scripts/seed.php
 * ============================================================
 * Seeds the database with an admin user and sample projects.
 *
 * Run once:   php scripts/seed.php
 * Re-seed:    php scripts/seed.php --fresh   (clears all data first)
 * ============================================================
 */

declare(strict_types=1);

define('ROOT_PATH', dirname(__DIR__));

require ROOT_PATH . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(ROOT_PATH);
$dotenv->safeLoad();

use App\Config\Database;
use App\Models\UserModel;
use App\Models\ProjectModel;
use App\Utils\Logger;

$logger = Logger::getInstance();
$fresh  = in_array('--fresh', $argv ?? [], true);

// ── Optional: reset tables ────────────────────────────────────
if ($fresh) {
    Database::execute('SET FOREIGN_KEY_CHECKS = 0');
    Database::execute('TRUNCATE TABLE messages');
    Database::execute('TRUNCATE TABLE projects');
    Database::execute('TRUNCATE TABLE users');
    Database::execute('SET FOREIGN_KEY_CHECKS = 1');
    $logger->info('Tables cleared (--fresh)');
}

// ── Admin user ────────────────────────────────────────────────
$adminEmail = $_ENV['ADMIN_EMAIL']    ?? 'esubalew.dev@gmail.com';
$adminPass  = $_ENV['ADMIN_PASSWORD'] ?? 'Admin@123456';
$adminName  = $_ENV['ADMIN_NAME']     ?? 'Esubalew Gebrehiwet';

if (!UserModel::emailExists($adminEmail)) {
    $hash = password_hash($adminPass, PASSWORD_BCRYPT, ['cost' => 12]);
    UserModel::create($adminName, $adminEmail, $hash);
    $logger->info("Admin created → {$adminEmail}");
} else {
    $logger->info("Admin already exists → skipping");
}

// ── Sample projects ───────────────────────────────────────────
$projects = [
    [
        'title'       => 'HopeForward Charity Website',
        'slug'        => 'hopeforward-charity',
        'category'    => 'web',
        'description' => 'Full-featured charity platform with donation processing, campaign management, donor portal, and real-time impact dashboard.',
        'tech'        => ['React', 'Node.js', 'Stripe', 'MongoDB', 'Email API'],
        'live_url'    => 'https://hopeforward.demo',
        'github_url'  => 'https://github.com/esubalew-dev/hopeforward',
        'featured'    => 1,
        'order'       => 1,
    ],
    [
        'title'       => 'School Management System',
        'slug'        => 'school-management-system',
        'category'    => 'system',
        'description' => 'Complete SMS with student enrollment, grade tracking, attendance, fee management, timetable, and parent portal.',
        'tech'        => ['Laravel', 'Vue.js', 'MySQL', 'Charts.js', 'PDF Reports'],
        'live_url'    => 'https://schoolpro.demo',
        'github_url'  => 'https://github.com/esubalew-dev/school-ms',
        'featured'    => 1,
        'order'       => 2,
    ],
    [
        'title'       => 'LUXE E-Commerce Platform',
        'slug'        => 'luxe-ecommerce',
        'category'    => 'ecommerce',
        'description' => 'Modern e-commerce solution with product catalog, cart system, Stripe checkout, and full admin inventory management.',
        'tech'        => ['Next.js', 'Stripe', 'PostgreSQL', 'Redux', 'Vercel'],
        'live_url'    => 'https://luxe.demo',
        'github_url'  => 'https://github.com/esubalew-dev/luxe-store',
        'featured'    => 1,
        'order'       => 3,
    ],
    [
        'title'       => 'MediCare Hospital System',
        'slug'        => 'medicare-hospital',
        'category'    => 'system',
        'description' => 'Hospital management system with patient records, appointment scheduling, billing, lab results, and multi-role dashboards.',
        'tech'        => ['React', 'Node.js', 'PostgreSQL', 'JWT Auth', 'PDF'],
        'live_url'    => 'https://medicare.demo',
        'github_url'  => 'https://github.com/esubalew-dev/medicare',
        'featured'    => 0,
        'order'       => 4,
    ],
    [
        'title'       => 'TalentHQ HR Management',
        'slug'        => 'talenthq-hr',
        'category'    => 'system',
        'description' => 'Complete HR platform with employee records, payroll processing, leave management, recruitment pipeline, and reporting.',
        'tech'        => ['Laravel', 'React', 'MySQL', 'Redis', 'AWS S3'],
        'live_url'    => 'https://talenthq.demo',
        'github_url'  => 'https://github.com/esubalew-dev/talenthq',
        'featured'    => 0,
        'order'       => 5,
    ],
    [
        'title'       => 'PropNest Real Estate Platform',
        'slug'        => 'propnest-real-estate',
        'category'    => 'web',
        'description' => 'Property listing and management platform with advanced search filters, virtual tours, agent dashboard, and mortgage calculator.',
        'tech'        => ['Next.js', 'Node.js', 'MongoDB', 'Google Maps', 'Cloudinary'],
        'live_url'    => 'https://propnest.demo',
        'github_url'  => 'https://github.com/esubalew-dev/propnest',
        'featured'    => 0,
        'order'       => 6,
    ],
];

foreach ($projects as $data) {
    // Check by slug to avoid duplicates on re-run
    $existing = Database::queryOne(
        'SELECT id FROM projects WHERE slug = ? LIMIT 1',
        [$data['slug']]
    );

    if ($existing) {
        $logger->info("Project already exists → skipping: {$data['title']}");
        continue;
    }

    ProjectModel::create($data);
    $logger->info("Project seeded → {$data['title']}");
}

$logger->info('✅  Seeding complete!');
