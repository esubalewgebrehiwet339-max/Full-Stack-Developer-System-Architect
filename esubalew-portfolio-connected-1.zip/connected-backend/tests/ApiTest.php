<?php
/**
 * tests/ApiTest.php
 * ============================================================
 * PHPUnit integration tests for the portfolio PHP API.
 * Run: composer test   OR   ./vendor/bin/phpunit --testdox
 * ============================================================
 */

declare(strict_types=1);

namespace Tests;

use PHPUnit\Framework\TestCase;

class ApiTest extends TestCase
{
    private string $baseUrl;

    protected function setUp(): void
    {
        // Point at your running dev server: php -S localhost:5000 -t public
        $this->baseUrl = getenv('API_BASE_URL') ?: 'http://localhost:5000';
    }

    // ── Helper ────────────────────────────────────────────────

    /**
     * Make a cURL HTTP request and return [statusCode, body].
     */
    private function request(
        string $method,
        string $path,
        array  $body   = [],
        array  $headers = []
    ): array {
        $url = $this->baseUrl . $path;
        $ch  = curl_init($url);

        $defaultHeaders = ['Content-Type: application/json', 'Accept: application/json'];
        $allHeaders     = array_merge($defaultHeaders, $headers);

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CUSTOMREQUEST  => strtoupper($method),
            CURLOPT_HTTPHEADER     => $allHeaders,
        ]);

        if (!empty($body)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }

        $response   = curl_exec($ch);
        $statusCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return [$statusCode, json_decode($response ?: '{}', true) ?? []];
    }

    // ── Health check ──────────────────────────────────────────

    public function test_health_endpoint_returns_200(): void
    {
        [$status, $body] = $this->request('GET', '/api/health');
        $this->assertSame(200, $status);
        $this->assertTrue($body['success']);
    }

    // ── Auth ──────────────────────────────────────────────────

    public function test_login_fails_with_missing_fields(): void
    {
        [$status, $body] = $this->request('POST', '/api/auth/login', []);
        $this->assertSame(422, $status);
        $this->assertFalse($body['success']);
        $this->assertArrayHasKey('errors', $body);
    }

    public function test_login_fails_with_invalid_email(): void
    {
        [$status, $body] = $this->request('POST', '/api/auth/login', [
            'email'    => 'not-an-email',
            'password' => 'secret123',
        ]);
        $this->assertSame(422, $status);
    }

    public function test_login_fails_with_wrong_credentials(): void
    {
        [$status, $body] = $this->request('POST', '/api/auth/login', [
            'email'    => 'nobody@example.com',
            'password' => 'wrongpassword',
        ]);
        $this->assertSame(401, $status);
        $this->assertFalse($body['success']);
    }

    // ── Projects (public) ─────────────────────────────────────

    public function test_get_projects_returns_200(): void
    {
        [$status, $body] = $this->request('GET', '/api/projects');
        $this->assertSame(200, $status);
        $this->assertTrue($body['success']);
        $this->assertIsArray($body['data']);
    }

    public function test_get_featured_projects(): void
    {
        [$status, $body] = $this->request('GET', '/api/projects/featured');
        $this->assertSame(200, $status);
        $this->assertIsArray($body['data']);
    }

    public function test_get_project_by_nonexistent_slug_returns_404(): void
    {
        [$status, $body] = $this->request('GET', '/api/projects/this-does-not-exist');
        $this->assertSame(404, $status);
        $this->assertFalse($body['success']);
    }

    public function test_projects_category_filter(): void
    {
        [$status, $body] = $this->request('GET', '/api/projects?category=web');
        $this->assertSame(200, $status);
        foreach ($body['data'] ?? [] as $project) {
            $this->assertSame('web', $project['category']);
        }
    }

    // ── Contact form ──────────────────────────────────────────

    public function test_contact_fails_with_empty_body(): void
    {
        [$status, $body] = $this->request('POST', '/api/contact', []);
        $this->assertSame(422, $status);
        $this->assertArrayHasKey('errors', $body);
    }

    public function test_contact_fails_with_invalid_email(): void
    {
        [$status, $body] = $this->request('POST', '/api/contact', [
            'name'    => 'Test User',
            'email'   => 'not-an-email',
            'message' => 'This is a long enough test message for validation purposes.',
        ]);
        $this->assertSame(422, $status);
        $fields = array_column($body['errors'] ?? [], 'field');
        $this->assertContains('email', $fields);
    }

    public function test_contact_fails_with_short_message(): void
    {
        [$status, $body] = $this->request('POST', '/api/contact', [
            'name'    => 'Test User',
            'email'   => 'test@example.com',
            'message' => 'Short',
        ]);
        $this->assertSame(422, $status);
        $fields = array_column($body['errors'] ?? [], 'field');
        $this->assertContains('message', $fields);
    }

    // ── Protected routes (no token) ───────────────────────────

    public function test_get_messages_without_token_returns_401(): void
    {
        [$status] = $this->request('GET', '/api/contact');
        $this->assertSame(401, $status);
    }

    public function test_dashboard_stats_without_token_returns_401(): void
    {
        [$status] = $this->request('GET', '/api/dashboard/stats');
        $this->assertSame(401, $status);
    }

    public function test_create_project_without_token_returns_401(): void
    {
        [$status] = $this->request('POST', '/api/projects', [
            'title'    => 'Hacked project',
            'category' => 'web',
        ]);
        $this->assertSame(401, $status);
    }

    public function test_delete_project_without_token_returns_401(): void
    {
        [$status] = $this->request('DELETE', '/api/projects/1');
        $this->assertSame(401, $status);
    }

    // ── 404 ───────────────────────────────────────────────────

    public function test_unknown_route_returns_404(): void
    {
        [$status, $body] = $this->request('GET', '/api/does-not-exist');
        $this->assertSame(404, $status);
        $this->assertFalse($body['success']);
    }
}
