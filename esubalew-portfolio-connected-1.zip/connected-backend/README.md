# Esubalew Gebrehiwet — PHP Portfolio Backend API v2.0

Production-ready **PHP 8.1 + MySQL** REST API backend for the portfolio website. Zero framework dependencies — pure PHP with a handful of best-in-class Composer packages.

---

## 📁 Project Structure

```
portfolio-php/
├── public/
│   ├── index.php          ← Front controller (every request enters here)
│   └── .htaccess          ← Apache URL rewriting + security rules
├── app/
│   ├── Controllers/
│   │   ├── AuthController.php       ← Login / current user
│   │   ├── ProjectController.php    ← Projects CRUD
│   │   ├── ContactController.php    ← Contact form + inbox
│   │   └── DashboardController.php  ← Admin stats
│   ├── Middleware/
│   │   ├── AuthMiddleware.php        ← JWT Bearer verification
│   │   ├── CorsMiddleware.php        ← CORS headers
│   │   └── SecurityHeadersMiddleware.php ← Security headers (Helmet equiv.)
│   ├── Models/
│   │   ├── UserModel.php            ← users table
│   │   ├── ProjectModel.php         ← projects table (JSON tech column)
│   │   └── MessageModel.php         ← messages table
│   ├── Routes/
│   │   └── Router.php               ← Lightweight front-controller router
│   ├── Services/
│   │   └── EmailService.php         ← PHPMailer + HTML email templates
│   └── Utils/
│       ├── Response.php             ← Standardised JSON responses
│       ├── Validator.php            ← Rule-based input validator
│       ├── Logger.php               ← Monolog singleton logger
│       ├── RateLimiter.php          ← MySQL-backed rate limiter
│       └── helpers.php              ← Global utility functions
├── config/
│   ├── database.php                 ← PDO MySQL singleton
│   └── schema.sql                   ← Database schema (run once)
├── scripts/
│   └── seed.php                     ← Seed admin + sample projects
├── tests/
│   └── ApiTest.php                  ← PHPUnit integration tests
├── storage/
│   ├── logs/                        ← App log files (production)
│   └── cache/                       ← Reserved for caching
├── .env.example                     ← Environment variable template
├── composer.json
└── phpunit.xml
```

---

## 🚀 Quick Start

### 1. Prerequisites
- **PHP** ≥ 8.1 with extensions: `pdo_mysql`, `json`, `mbstring`, `openssl`
- **MySQL** ≥ 5.7 or MariaDB ≥ 10.3
- **Composer** ≥ 2.0

### 2. Install dependencies
```bash
cd portfolio-php
composer install
```

### 3. Configure environment
```bash
cp .env.example .env
# Edit .env — set DB_*, MAIL_*, JWT_SECRET, etc.
```

### 4. Create database & run schema
```bash
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS portfolio CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p portfolio < config/schema.sql
```

### 5. Seed the database
```bash
php scripts/seed.php
# Creates admin user + 6 sample projects

# Full reset: php scripts/seed.php --fresh
```

### 6. Start development server
```bash
# PHP built-in server (development only)
php -S 0.0.0.0:5000 -t public public/index.php

# OR use Apache/Nginx (see Deployment section)
```

Server running at: **http://localhost:5000**

---

## 🌐 API Reference

All responses follow this envelope:
```json
{
  "success": true,
  "message": "...",
  "data": { ... },
  "meta": { "page": 1, "limit": 10, "total": 25, "pages": 3 }
}
```

### Auth
| Method | Endpoint        | Auth   | Description           |
|--------|-----------------|--------|-----------------------|
| POST   | /api/auth/login | Public | Login → get JWT token |
| GET    | /api/auth/me    | JWT    | Get current admin     |

**Login request body:**
```json
{ "email": "esubalew.dev@gmail.com", "password": "Admin@123456" }
```
**Login response:**
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGci...",
    "expiresIn": "168h",
    "user": { "id": 1, "name": "Esubalew Gebrehiwet", "email": "...", "role": "admin" }
  }
}
```

Use the token in subsequent requests:
```
Authorization: Bearer eyJhbGci...
```

---

### Projects (Public)
| Method | Endpoint                | Description                  |
|--------|-------------------------|------------------------------|
| GET    | /api/projects           | Paginated published projects |
| GET    | /api/projects/featured  | Featured projects only       |
| GET    | /api/projects/{slug}    | Single project by slug       |

**Query params for GET /api/projects:**
| Param      | Example              | Description                    |
|------------|----------------------|--------------------------------|
| `category` | `?category=system`   | Filter by category             |
| `featured` | `?featured=true`     | Featured only                  |
| `page`     | `?page=2`            | Page number (default: 1)       |
| `limit`    | `?limit=6`           | Per page (default: 10, max: 50)|
| `sort`     | `?sort=-created_at`  | Prefix `-` for DESC            |

### Projects (Admin — requires `Authorization: Bearer <token>`)
| Method | Endpoint                       | Description            |
|--------|--------------------------------|------------------------|
| GET    | /api/projects/admin/all        | All (incl. unpublished)|
| POST   | /api/projects                  | Create project         |
| PUT    | /api/projects/{id}             | Update project         |
| DELETE | /api/projects/{id}             | Delete project         |
| PATCH  | /api/projects/{id}/toggle      | Toggle published       |

**Create / Update project body:**
```json
{
  "title":       "My Project",
  "category":    "web",
  "description": "A great project.",
  "tech":        ["PHP", "MySQL", "Vue.js"],
  "live_url":    "https://myproject.com",
  "github_url":  "https://github.com/me/project",
  "featured":    1,
  "order":       1,
  "is_published": 1
}
```

---

### Contact
| Method | Endpoint                     | Auth   | Description              |
|--------|------------------------------|--------|--------------------------|
| POST   | /api/contact                 | Public | Submit form (5/15min limit) |
| GET    | /api/contact                 | JWT    | List messages            |
| GET    | /api/contact/{id}            | JWT    | Single message (auto-read)|
| PATCH  | /api/contact/{id}/status     | JWT    | Update status            |
| DELETE | /api/contact/{id}            | JWT    | Delete message           |

**Contact form body:**
```json
{
  "name":         "John Doe",
  "email":        "john@example.com",
  "project_type": "Web Application",
  "budget":       "$500 – $1,000",
  "message":      "I need a web application built for my business..."
}
```

**Update status body:**
```json
{ "status": "replied", "admin_reply": "Optional internal note" }
```
Valid statuses: `new` | `read` | `replied` | `archived`

---

### Dashboard (Admin)
| Method | Endpoint             | Auth | Description     |
|--------|----------------------|------|-----------------|
| GET    | /api/dashboard/stats | JWT  | Aggregate stats |

---

### Health Check
```
GET /api/health → { "success": true, "message": "Portfolio API is running" }
```

---

## 🔒 Security Features

| Feature              | Implementation                                |
|----------------------|-----------------------------------------------|
| JWT Authentication   | `firebase/php-jwt` — HS256, configurable expiry |
| Password Hashing     | `password_hash()` — bcrypt cost 12            |
| Security Headers     | X-Content-Type-Options, X-Frame-Options, CSP, HSTS |
| Rate Limiting        | MySQL-backed — 100/15min global, 5/15min contact |
| Input Validation     | Custom Validator on all POST/PUT bodies        |
| SQL Injection        | PDO prepared statements everywhere            |
| XSS Prevention       | `htmlspecialchars()` on all user output       |
| CORS                 | Whitelist-based origin checking               |
| NoSQL/payload attack | N/A — uses relational MySQL                   |

---

## 📧 Gmail SMTP Setup

1. Enable **2-Factor Authentication** on your Google account
2. Go to **Google Account → Security → App Passwords**
3. Create an App Password for **Mail / Other**
4. Copy the 16-character password to `MAIL_PASSWORD` in `.env`

---

## 🧪 Testing

```bash
# Start the dev server first
php -S localhost:5000 -t public public/index.php &

# Run tests
composer test
```

**Test coverage:**
- `GET /api/health` → 200 ✓
- Login validation (missing fields, bad email, wrong credentials) ✓
- `GET /api/projects` → 200 + data array ✓
- Featured projects ✓
- Category filter ✓
- 404 for unknown slug ✓
- Contact validation (empty, bad email, short message) ✓
- All admin routes return 401 without token ✓
- Unknown route returns 404 ✓

---

## ☁️ Deployment

### Apache (cPanel / Shared Hosting)
1. Upload contents of `portfolio-php/` to your server
2. Point document root to the `public/` directory
3. Create `.env` with production values
4. Run `composer install --no-dev --optimize-autoloader`
5. Import `config/schema.sql` via phpMyAdmin
6. Run `php scripts/seed.php`

The `.htaccess` in `public/` handles URL rewriting automatically.

### Nginx (VPS)
```nginx
server {
    listen 80;
    server_name api.yourdomain.com;
    root /var/www/portfolio-php/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Block access to sensitive files
    location ~ /\.(env|git) { deny all; }
}
```

### Docker (optional)
```dockerfile
FROM php:8.1-apache
RUN docker-php-ext-install pdo_mysql
COPY . /var/www/html
RUN mv /var/www/html/public /var/www/html/public && \
    sed -i 's|/var/www/html|/var/www/html/public|' /etc/apache2/sites-available/000-default.conf
RUN a2enmod rewrite
```

---

## 🔗 Connect the Frontend

In your portfolio `js/script.js`, update the `initContactForm()` function:

```javascript
// Replace the setTimeout simulation with:
const res = await fetch('https://your-api-url.com/api/contact', {
  method:  'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name:         form.querySelector('#fname').value,
    email:        form.querySelector('#femail').value,
    project_type: form.querySelector('#ftype').value,
    budget:       form.querySelector('#fbudget').value,
    message:      form.querySelector('#fmessage').value,
  }),
});
const data = await res.json();
if (!res.ok) throw new Error(data.message);
```

---

## ⚙️ Cron Job (Rate Limiter Cleanup)

Add to crontab to clean expired rate-limit rows daily:
```bash
0 3 * * * /usr/bin/php /var/www/portfolio-php/scripts/cleanup.php
```

---

© 2025 Esubalew Gebrehiwet · esubalew.dev@gmail.com
