/**
 * ============================================================
 * Esubalew Gebrehiwet — Portfolio Script
 * Author  : Esubalew Gebrehiwet
 * Version : 2.0
 *
 * TABLE OF CONTENTS
 * -----------------
 * 01. Utilities
 * 02. Custom Cursor
 * 03. Header — scroll behaviour & active link
 * 04. Mobile Menu
 * 05. Hero Canvas — particle network
 * 06. Hero Stat Counters
 * 07. Tech Ticker — duplicate for infinite loop
 * 08. Scroll Reveal (IntersectionObserver)
 * 09. Skills — tab filter + bar animation
 * 10. Projects — filter
 * 11. Contact Form — validation + submit
 * 12. Back-to-top Button
 * 13. Footer year
 * 14. Init
 * ============================================================
 */

'use strict';

/* ============================================================
   00. API CONFIGURATION
   ── Set API_BASE to wherever your PHP backend is hosted.
   ── In development with Live Server on port 5500 and PHP on
      port 8000, use 'http://localhost:8000'. In production,
      set it to your domain (e.g. 'https://api.yourdomain.com')
      or '' if frontend & backend share the same origin.
============================================================ */
const API_BASE = window.PORTFOLIO_API_BASE || 'http://localhost:8000';


/* ============================================================
   01. UTILITIES
============================================================ */

/**
 * Shorthand querySelector
 * @param {string} sel - CSS selector
 * @param {Element} [ctx=document] - context element
 * @returns {Element|null}
 */
const $ = (sel, ctx = document) => ctx.querySelector(sel);

/**
 * Shorthand querySelectorAll → array
 * @param {string} sel
 * @param {Element} [ctx=document]
 * @returns {Element[]}
 */
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/**
 * Clamp a number between min and max
 */
const clamp = (val, min, max) => Math.min(Math.max(val, min), max);


/* ============================================================
   02. CUSTOM CURSOR
============================================================ */
function initCursor() {
  const cursor     = $('#cursor');
  const cursorRing = $('#cursorRing');

  // Skip on touch-only devices
  if (!cursor || !cursorRing || window.matchMedia('(hover: none)').matches) return;

  let mouseX = 0, mouseY = 0;
  let ringX  = 0, ringY  = 0;
  let rafId  = null;

  // Move dot cursor instantly
  document.addEventListener('mousemove', e => {
    mouseX = e.clientX;
    mouseY = e.clientY;
    cursor.style.left = `${mouseX}px`;
    cursor.style.top  = `${mouseY}px`;
  });

  // Animate ring with lag for smooth trailing effect
  function animateRing() {
    ringX += (mouseX - ringX) * 0.13;
    ringY += (mouseY - ringY) * 0.13;
    cursorRing.style.left = `${ringX}px`;
    cursorRing.style.top  = `${ringY}px`;
    rafId = requestAnimationFrame(animateRing);
  }
  animateRing();

  // Scale up ring on interactive elements
  const interactiveSelector = 'a, button, .demo-card, .skill-card, .project-card, .service-card, .filter-btn, .skills__tab, input, select, textarea';

  document.addEventListener('mouseover', e => {
    if (e.target.closest(interactiveSelector)) {
      cursorRing.classList.add('is-hovering');
    }
  });

  document.addEventListener('mouseout', e => {
    if (e.target.closest(interactiveSelector)) {
      cursorRing.classList.remove('is-hovering');
    }
  });

  // Hide when leaving viewport
  document.addEventListener('mouseleave', () => {
    cursor.style.opacity     = '0';
    cursorRing.style.opacity = '0';
  });

  document.addEventListener('mouseenter', () => {
    cursor.style.opacity     = '1';
    cursorRing.style.opacity = '1';
  });
}


/* ============================================================
   03. HEADER — SCROLL BEHAVIOUR & ACTIVE NAV LINK
============================================================ */
function initHeader() {
  const header   = $('#header');
  const navLinks = $$('.nav__link');
  const sections = $$('section[id]');

  if (!header) return;

  // Add scrolled class when page is scrolled
  function onScroll() {
    header.classList.toggle('is-scrolled', window.scrollY > 40);
    updateActiveLink();
  }

  // Highlight the nav link whose section is in view
  function updateActiveLink() {
    let currentId = '';
    const offset  = window.innerHeight * 0.35;

    sections.forEach(section => {
      const rect = section.getBoundingClientRect();
      if (rect.top <= offset) {
        currentId = section.id;
      }
    });

    navLinks.forEach(link => {
      const href = link.getAttribute('href')?.replace('#', '');
      link.classList.toggle('is-active', href === currentId);
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll(); // run on init
}


/* ============================================================
   04. MOBILE MENU
============================================================ */
function initMobileMenu() {
  const toggle     = $('#navToggle');
  const menu       = $('#mobileMenu');
  const menuLinks  = $$('.mobile-menu__link');

  if (!toggle || !menu) return;

  function openMenu() {
    menu.classList.add('is-open');
    toggle.classList.add('is-open');
    toggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    menu.classList.remove('is-open');
    toggle.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  toggle.addEventListener('click', () => {
    const isOpen = menu.classList.contains('is-open');
    isOpen ? closeMenu() : openMenu();
  });

  // Close when a link is clicked
  menuLinks.forEach(link => link.addEventListener('click', closeMenu));

  // Close on Escape key
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeMenu();
  });
}


/* ============================================================
   05. HERO CANVAS — PARTICLE NETWORK
============================================================ */
function initHeroCanvas() {
  const canvas = $('#heroCanvas');
  if (!canvas) return;

  // Respect reduced-motion preference
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    canvas.style.display = 'none';
    return;
  }

  const ctx = canvas.getContext('2d');
  let W, H, particles = [];

  /** Resize canvas to full window */
  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }

  resize();
  window.addEventListener('resize', resize);

  /** A single particle */
  class Particle {
    constructor() { this.reset(); }

    reset() {
      this.x     = Math.random() * W;
      this.y     = Math.random() * H;
      this.size  = Math.random() * 1.4 + 0.3;
      this.vx    = (Math.random() - 0.5) * 0.28;
      this.vy    = (Math.random() - 0.5) * 0.28;
      this.alpha = Math.random() * 0.55 + 0.1;
      // Mix sky-blue and indigo particles
      this.color = Math.random() > 0.5 ? '56,189,248' : '129,140,248';
    }

    update() {
      this.x += this.vx;
      this.y += this.vy;
      // Wrap around edges
      if (this.x < -2) this.x = W + 2;
      if (this.x > W + 2) this.x = -2;
      if (this.y < -2) this.y = H + 2;
      if (this.y > H + 2) this.y = -2;
    }

    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${this.color},${this.alpha})`;
      ctx.fill();
    }
  }

  // Create particle pool
  const COUNT = Math.min(100, Math.floor((window.innerWidth * window.innerHeight) / 12000));
  for (let i = 0; i < COUNT; i++) {
    particles.push(new Particle());
  }

  /** Draw connection lines between nearby particles */
  function drawConnections() {
    const maxDist = 130;
    ctx.lineWidth = 0.5;

    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx   = particles[i].x - particles[j].x;
        const dy   = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < maxDist) {
          const alpha = (1 - dist / maxDist) * 0.25;
          ctx.strokeStyle = `rgba(56,189,248,${alpha})`;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }
  }

  /** Main animation loop */
  function animate() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => { p.update(); p.draw(); });
    drawConnections();
    requestAnimationFrame(animate);
  }

  animate();
}


/* ============================================================
   06. HERO STAT COUNTERS
============================================================ */
function initCounters() {
  const statsWrap = $('.hero__stats');
  if (!statsWrap) return;

  let animated = false;

  /** Animate a single counter element */
  function animateCounter(el) {
    const target   = parseInt(el.dataset.count, 10);
    const duration = 1400; // ms
    const start    = performance.now();

    function step(now) {
      const elapsed  = now - start;
      const progress = clamp(elapsed / duration, 0, 1);
      // Ease-out quart
      const eased = 1 - Math.pow(1 - progress, 4);
      el.textContent = Math.floor(eased * target);
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = target; // ensure exact final value
    }

    requestAnimationFrame(step);
  }

  const observer = new IntersectionObserver(entries => {
    if (entries[0].isIntersecting && !animated) {
      animated = true;
      $$('[data-count]').forEach(animateCounter);
    }
  }, { threshold: 0.5 });

  observer.observe(statsWrap);
}


/* ============================================================
   07. TECH TICKER — DUPLICATE FOR SEAMLESS LOOP
============================================================ */
function initTicker() {
  const track = $('#tickerTrack');
  if (!track) return;

  // Duplicate all children so the track is 2× wide,
  // allowing CSS to animate the first half out while second half follows.
  const items = track.innerHTML;
  track.innerHTML = items + items;
}


/* ============================================================
   08. SCROLL REVEAL (IntersectionObserver)
============================================================ */
function initReveal() {
  const targets = $$('.reveal-up, .reveal-fade, .reveal-left, .reveal-right');
  if (!targets.length) return;

  // Respect reduced-motion: reveal immediately
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    targets.forEach(el => el.classList.add('revealed'));
    return;
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target); // fire once
      }
    });
  }, {
    threshold:  0.12,
    rootMargin: '0px 0px -40px 0px',
  });

  targets.forEach(el => observer.observe(el));
}


/* ============================================================
   09. SKILLS — TAB FILTER + PROGRESS BAR ANIMATION
============================================================ */
function initSkills() {
  const tabs     = $$('.skills__tab');
  const cards    = $$('.skill-card');
  const grid     = $('#skillsGrid');

  if (!tabs.length || !cards.length) return;

  // Animate skill bars when they scroll into view
  const barObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const fill = entry.target.querySelector('.skill-card__fill');
        if (fill) {
          // Trigger CSS transition by setting width = custom property
          fill.style.width = fill.style.getPropertyValue('--pct') || fill.dataset.pct || '0%';
        }
      }
    });
  }, { threshold: 0.4 });

  cards.forEach(card => barObserver.observe(card));

  // Tab switching
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const category = tab.dataset.tab;

      // Update active tab styling
      tabs.forEach(t => {
        t.classList.remove('skills__tab--active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('skills__tab--active');
      tab.setAttribute('aria-selected', 'true');

      // Show/hide cards
      cards.forEach(card => {
        const match = category === 'all' || card.dataset.category === category;
        card.classList.toggle('is-hidden', !match);

        // Re-animate bars for newly visible cards
        if (match) {
          const fill = card.querySelector('.skill-card__fill');
          if (fill) {
            fill.style.width = '0%';
            // Slight delay so reset is painted before animating
            requestAnimationFrame(() => {
              requestAnimationFrame(() => {
                fill.style.width = fill.style.getPropertyValue('--pct') || '0%';
              });
            });
          }
        }
      });
    });
  });
}


/* ============================================================
   10. PROJECTS — DYNAMIC API LOAD + FILTER
============================================================ */

/** Build a project card element from an API project object */
function buildProjectCard(project, delay) {
  const tags = Array.isArray(project.tags)
    ? project.tags
    : (project.tags ? JSON.parse(project.tags) : []);

  const demoLink = project.demo_url
    ? `<a href="${project.demo_url}" class="btn btn--small btn--primary" target="_blank" rel="noopener" aria-label="View ${project.title} demo">View Demo →</a>`
    : '';

  const githubSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>`;

  const codeLink = project.github_url
    ? `<a href="${project.github_url}" class="btn btn--small btn--ghost" target="_blank" rel="noopener" aria-label="View ${project.title} source code">${githubSvg} Code</a>`
    : '';

  const category = (project.category || 'web').toLowerCase();

  const article = document.createElement('article');
  article.className = 'project-card reveal-up';
  article.dataset.category = category;
  article.style.cssText = `--delay:${delay}s`;
  article.setAttribute('role', 'listitem');

  article.innerHTML = `
    <div class="project-card__preview" aria-hidden="true"
         style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); display:flex; align-items:center; justify-content:center; min-height:180px;">
      <div class="project-card__overlay"></div>
      <div class="project-card__preview-content" style="text-align:center; padding:1rem;">
        <div style="font-size:2.5rem; margin-bottom:.5rem;">${project.icon || '💻'}</div>
        <div style="color:#38bdf8; font-weight:700; font-size:1rem;">${project.title}</div>
      </div>
      <span class="project-card__badge">${project.featured ? 'Featured' : category}</span>
    </div>
    <div class="project-card__body">
      <p class="project-card__category">${project.category || 'Web'}</p>
      <h3 class="project-card__title">${project.title}</h3>
      <p class="project-card__desc">${project.description || ''}</p>
      <ul class="project-card__tags" role="list">
        ${tags.map(t => `<li>${t}</li>`).join('')}
      </ul>
      <div class="project-card__actions">
        ${demoLink}
        ${codeLink}
      </div>
    </div>
  `;

  return article;
}

async function initProjectFilter() {
  const filterBtns = $$('.filter-btn');
  const grid       = $('#projectsGrid');

  if (!grid) return;

  let allProjects = [];
  let activeFilter = 'all';

  /** Render currently filtered projects */
  function renderProjects() {
    const filtered = activeFilter === 'all'
      ? allProjects
      : allProjects.filter(p => (p.category || '').toLowerCase() === activeFilter);

    grid.innerHTML = '';
    filtered.forEach((p, i) => {
      const card = buildProjectCard(p, 0.1 + i * 0.1);
      grid.appendChild(card);
    });

    // Re-run scroll reveal on new cards
    $$('.project-card.reveal-up', grid).forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(30px)';
      requestAnimationFrame(() => {
        el.style.transition = 'opacity .5s ease, transform .5s ease';
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      });
    });
  }

  // Filter button click handling
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      activeFilter = btn.dataset.filter;
      filterBtns.forEach(b => b.classList.remove('filter-btn--active'));
      btn.classList.add('filter-btn--active');
      renderProjects();
    });
  });

  // Fetch projects from API
  try {
    grid.innerHTML = '<p style="text-align:center;color:var(--clr-text-muted);padding:2rem;">Loading projects…</p>';
    const res = await fetch(`${API_BASE}/api/projects?limit=50`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    allProjects = data.data || data.projects || data || [];

    if (allProjects.length === 0) throw new Error('No projects returned');
    renderProjects();

  } catch (err) {
    console.warn('Could not load projects from API, falling back to static HTML.', err);
    // Leave existing static HTML in place — no-op
    grid.innerHTML = grid.innerHTML || '<p style="text-align:center;color:var(--clr-text-muted);padding:2rem;">Projects coming soon.</p>';

    // Still wire up filter for any existing static cards
    const cards = $$('.project-card', grid);
    if (cards.length) {
      filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
          const filter = btn.dataset.filter;
          filterBtns.forEach(b => b.classList.remove('filter-btn--active'));
          btn.classList.add('filter-btn--active');
          cards.forEach(card => {
            const match = filter === 'all' || card.dataset.category === filter;
            card.classList.toggle('is-hidden', !match);
          });
        });
      });
    }
  }
}


/* ============================================================
   11. CONTACT FORM — VALIDATION + SUBMIT
============================================================ */
function initContactForm() {
  const form       = $('#contactForm');
  const submitBtn  = $('#formSubmit');
  const successMsg = $('#formSuccess');

  if (!form) return;

  /** Validate a single field, return error message or '' */
  function validateField(input) {
    const val = input.value.trim();

    if (input.required && !val) {
      return 'This field is required.';
    }

    if (input.type === 'email' && val) {
      const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRe.test(val)) return 'Please enter a valid email address.';
    }

    if (input.id === 'fmessage' && val && val.length < 20) {
      return 'Message must be at least 20 characters.';
    }

    return '';
  }

  /** Show/clear error for a field */
  function setError(input, message) {
    const errorEl = $(`#${input.id}-error`);
    if (errorEl) errorEl.textContent = message;
    input.classList.toggle('is-error', !!message);
  }

  /** Validate all required fields, return true if all pass */
  function validateForm() {
    const requiredInputs = $$('[required]', form);
    let valid = true;

    requiredInputs.forEach(input => {
      const err = validateField(input);
      setError(input, err);
      if (err) valid = false;
    });

    return valid;
  }

  // Live validation on blur
  $$('[required]', form).forEach(input => {
    input.addEventListener('blur', () => {
      const err = validateField(input);
      setError(input, err);
    });

    input.addEventListener('input', () => {
      if (input.classList.contains('is-error')) {
        const err = validateField(input);
        setError(input, err);
      }
    });
  });

  // Form submission
  form.addEventListener('submit', async e => {
    e.preventDefault();

    if (!validateForm()) return;

    // Loading state
    submitBtn.classList.add('is-loading');

    try {
      const res = await fetch(`${API_BASE}/api/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.fromEntries(new FormData(form))),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Server error');

      // Success
      form.reset();
      if (successMsg) {
        successMsg.hidden = false;
        successMsg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }

      // Hide success message after 6s
      setTimeout(() => {
        if (successMsg) successMsg.hidden = true;
      }, 6000);

    } catch (err) {
      console.error('Form submission error:', err);
      // Show a generic error to user
      const errorEl = document.createElement('p');
      errorEl.style.cssText = 'color:var(--clr-danger);font-size:.85rem;text-align:center;margin-top:8px;';
      errorEl.textContent = 'Something went wrong. Please try again or email directly.';
      form.appendChild(errorEl);
      setTimeout(() => errorEl.remove(), 5000);

    } finally {
      submitBtn.classList.remove('is-loading');
    }
  });
}


/* ============================================================
   12. BACK-TO-TOP BUTTON
============================================================ */
function initBackToTop() {
  const btn = $('#backToTop');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    btn.classList.toggle('is-visible', window.scrollY > 500);
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}


/* ============================================================
   13. FOOTER YEAR
============================================================ */
function initYear() {
  const el = $('#year');
  if (el) el.textContent = new Date().getFullYear();
}


/* ============================================================
   14. INIT — run all modules when DOM is ready
============================================================ */
async function init() {
  initCursor();
  initHeader();
  initMobileMenu();
  initHeroCanvas();
  initCounters();
  initTicker();
  initReveal();
  initSkills();
  await initProjectFilter();  // async — fetches from API
  initContactForm();
  initBackToTop();
  initYear();

  console.log('%c🚀 Esubalew Gebrehiwet Portfolio — loaded', 'color:#38bdf8;font-weight:bold;');
}

// Wait for DOM before initialising
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
