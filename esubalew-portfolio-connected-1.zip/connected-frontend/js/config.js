/**
 * js/config.js — API Configuration
 * ============================================================
 * Set PORTFOLIO_API_BASE to wherever your PHP backend runs.
 *
 *  Development (PHP built-in server on port 8000):
 *    window.PORTFOLIO_API_BASE = 'http://localhost:8000';
 *
 *  Production (same domain, backend in /api/ subdirectory):
 *    window.PORTFOLIO_API_BASE = '';   // empty = same origin
 *
 *  Production (separate API subdomain):
 *    window.PORTFOLIO_API_BASE = 'https://api.yourdomain.com';
 * ============================================================
 */
window.PORTFOLIO_API_BASE = 'http://localhost:8000';
