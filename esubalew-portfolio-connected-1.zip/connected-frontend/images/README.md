# /images

Place your project screenshots and assets here.

## Recommended file names:
- `og-image.jpg`       — Open Graph share image (1200×630px)
- `favicon.png`        — Site favicon (32×32px)
- `project-charity.jpg`
- `project-school.jpg`
- `project-ecommerce.jpg`
- `project-hospital.jpg`
- `project-hr.jpg`
- `project-realestate.jpg`

## To use an image in index.html:
```html
<img src="images/your-image.jpg" alt="Descriptive alt text" width="600" height="400" loading="lazy" />
```

Use `loading="lazy"` for all below-the-fold images to improve performance.
