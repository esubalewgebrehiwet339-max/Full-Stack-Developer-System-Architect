# Esubalew Gebrehiwet — Developer Portfolio v2.0

A modern, animated, fully responsive developer portfolio built with **pure HTML5 / CSS3 / Vanilla JavaScript** — zero dependencies, zero build tools required.

---

## 📁 Project Structure

```
portfolio/
├── index.html          ← Main HTML (semantic, accessible, SEO-ready)
├── css/
│   └── style.css       ← Complete stylesheet (750+ lines, well-commented)
├── js/
│   └── script.js       ← All interactions (600+ lines, well-commented)
├── images/             ← Place project screenshots / assets here
└── README.md           ← This file
```

---

## ✨ Features

| Feature | Details |
|---|---|
| **Custom Cursor** | Smooth magnetic cursor with hover ring effect |
| **Animated Hero** | Particle canvas, floating code card, staggered text reveals |
| **Tech Ticker** | Infinite scrolling tech stack banner |
| **Scroll Reveal** | IntersectionObserver — elements animate in as you scroll |
| **Stat Counters** | Animated number counters on scroll |
| **Skills Tabs** | Filter by Frontend / Backend / Database / DevOps with bar animations |
| **Project Filter** | Filter 6 projects by category |
| **Services** | 6 service cards with featured highlight |
| **Process** | 5-step interactive workflow section |
| **Testimonials** | 3 client reviews |
| **Contact Form** | Full client-side validation + loading states |
| **Back-to-top** | Smooth scroll button |
| **Mobile Menu** | Full-screen animated mobile navigation |
| **Responsive** | Mobile-first, tested at 320px → 1440px+ |
| **Accessible** | ARIA labels, semantic HTML, focus rings, reduced-motion support |
| **SEO Ready** | Meta tags, Open Graph, semantic headings |

---

## 🚀 Quick Start

### Open Locally
Just open `index.html` in any modern browser. No server needed.

### Deploy — Netlify (Free, Recommended)
1. Go to [netlify.com](https://netlify.com) → sign up free
2. Drag and drop the entire `portfolio/` folder onto the dashboard
3. ✅ Your site is live instantly!

### Deploy — GitHub Pages
1. Push this folder to a GitHub repo
2. Settings → Pages → Source: `main` branch, `/ (root)`
3. Live at `https://yourusername.github.io/repo-name`

### Deploy — Vercel
```bash
npm i -g vercel
cd portfolio
vercel
```

### Deploy — cPanel / Shared Hosting
Upload contents of `portfolio/` to your `public_html` directory via File Manager or FTP.

---

## ✏️ Customisation

All personal details are in `index.html`. Search for these to update:

| What | Search for |
|---|---|
| Name | `Esubalew Gebrehiwet` |
| Email | `esubalew.dev@gmail.com` |
| Upwork URL | `upwork.com/fl/esubalew` |
| GitHub URL | `github.com/esubalew-dev` |
| LinkedIn URL | `linkedin.com/in/esubalew-dev` |
| Stats | `data-count="50"` |
| Services pricing | `Starting at` |

### Colour Scheme
Edit CSS variables at the top of `css/style.css` (`:root` block):
```css
--clr-accent:   #38bdf8;   /* sky blue  */
--clr-accent-2: #818cf8;   /* indigo    */
--clr-accent-3: #34d399;   /* emerald   */
```

### Connect the Contact Form
In `js/script.js`, find the `initContactForm` function and replace the `setTimeout` simulation with your real endpoint:

**Option A — Custom API:**
```js
const res = await fetch('/api/contact', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(Object.fromEntries(new FormData(form))),
});
```

**Option B — Formspree (easiest):**
1. Sign up at [formspree.io](https://formspree.io)
2. Set `form.action = 'https://formspree.io/f/YOUR_ID'`

---

## 🛠 Tech Stack

- **HTML5** — Semantic elements, ARIA, Open Graph meta
- **CSS3** — Custom properties, Grid, Flexbox, animations, clamp()
- **JavaScript (ES2020)** — Modules pattern, async/await, IntersectionObserver, Canvas API
- **Google Fonts** — Syne (display) + Outfit (body) + DM Mono (code)
- **Zero dependencies** — No React, no jQuery, no build step

---

## 📞 Contact

**Esubalew Gebrehiwet**
- 📧 esubalew.dev@gmail.com
- 💼 upwork.com/fl/esubalew
- 🐙 github.com/esubalew-dev
- 🔗 linkedin.com/in/esubalew-dev

---

© 2025 Esubalew Gebrehiwet. All rights reserved.
